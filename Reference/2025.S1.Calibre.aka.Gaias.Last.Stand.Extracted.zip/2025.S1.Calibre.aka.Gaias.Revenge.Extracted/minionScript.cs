using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.InputSystem;

public class minionScript : MonoBehaviour
{
	[Header("Health System")]
	[SerializeField]
	private float maxLife = 30f;

	private float currentHealth;

	[Header("NavMesh & Movement")]
	public float detectRange = 15f;

	public float stopDistance = 5f;

	private Transform player;

	private NavMeshAgent agent;

	[SerializeField]
	private LayerMask playerLayer = -1;

	[Header("Shooting System")]
	public GameObject bulletPrefab;

	public Transform firePoint;

	public float fireRate = 1f;

	public float bulletSpeed = 15f;

	private bool isFiring;

	[SerializeField]
	private Collider[] allPlayerCollidersFoundWithinDetectionRange;

	[SerializeField]
	private List<Transform> allPlayersWithinRange;

	private float startingNavMeshAgentSpeed;

	private float nextFireTime;

	[SerializeField]
	private float fireTimeInterval = 1f;

	public GameObject DeathExplosionEffect;

	public event Action<GameObject> OnEnemyDeath;

	private void Start()
	{
		agent = GetComponent<NavMeshAgent>();
		if (agent != null)
		{
			startingNavMeshAgentSpeed = agent.speed;
		}
		player = GameObject.FindGameObjectWithTag("Player")?.transform;
		currentHealth = maxLife;
	}

	private Transform FindNearestPlayer()
	{
		Transform result = null;
		float num = float.PositiveInfinity;
		Vector3 position = base.transform.position;
		foreach (Transform item in allPlayersWithinRange)
		{
			float num2 = Vector3.Distance(position, item.position);
			if (num2 < num)
			{
				num = num2;
				result = item;
			}
		}
		return result;
	}

	private Transform FindNearestPlayerLinqVersion()
	{
		return allPlayersWithinRange.OrderBy((Transform t) => Vector3.Distance(base.transform.position, t.position)).FirstOrDefault();
	}

	private void Update()
	{
		allPlayerCollidersFoundWithinDetectionRange = Physics.OverlapSphere(base.transform.position, detectRange, playerLayer);
		if (allPlayerCollidersFoundWithinDetectionRange.Length == 0)
		{
			return;
		}
		allPlayersWithinRange.Clear();
		Collider[] array = allPlayerCollidersFoundWithinDetectionRange;
		for (int i = 0; i < array.Length; i++)
		{
			if (array[i].TryGetComponent<PlayerInput>(out var component) && !allPlayersWithinRange.Contains(component.transform))
			{
				allPlayersWithinRange.Add(component.transform);
			}
		}
		player = FindNearestPlayerLinqVersion();
		if (!(player == null))
		{
			float num = Vector3.Distance(base.transform.position, player.position);
			agent.SetDestination(player.position);
			if (num < stopDistance)
			{
				agent.speed = 0f;
				Vector3 position = player.position;
				position.y = base.transform.position.y;
				agent.transform.LookAt(player.position);
				ShootAtPlayer();
			}
			else
			{
				agent.speed = startingNavMeshAgentSpeed;
			}
		}
	}

	private void ShootAtPlayer()
	{
		nextFireTime += Time.deltaTime;
		if (nextFireTime > fireTimeInterval)
		{
			Shoot();
			nextFireTime -= fireTimeInterval;
		}
	}

	private void Shoot()
	{
		if (bulletPrefab != null && firePoint != null)
		{
			UnityEngine.Object.Instantiate(bulletPrefab, firePoint.position, firePoint.rotation);
		}
	}

	public void TakeDamage(float damage)
	{
		currentHealth -= damage;
		if (currentHealth <= 0f)
		{
			Die();
		}
	}

	public void Die()
	{
		UnityEngine.Object.Destroy(UnityEngine.Object.Instantiate(DeathExplosionEffect, base.transform.position, Quaternion.identity), 2f);
		this.OnEnemyDeath?.Invoke(base.gameObject);
		base.gameObject.transform.position = new Vector3(0f, -9999f, 0f);
		UnityEngine.Object.Destroy(base.gameObject);
	}

	private void OnTriggerEnter(Collider other)
	{
		if (other.CompareTag("BasicBullet"))
		{
			TakeDamage(30f);
		}
		else if (other.CompareTag("Explosion"))
		{
			TakeDamage(30f);
		}
	}

	private void OnDrawGizmos()
	{
		Gizmos.DrawWireSphere(base.transform.position, detectRange);
	}
}
