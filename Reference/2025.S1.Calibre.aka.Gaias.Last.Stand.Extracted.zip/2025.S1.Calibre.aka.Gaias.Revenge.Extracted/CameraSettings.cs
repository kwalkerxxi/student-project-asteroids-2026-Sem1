using System.Collections;
using UnityEngine;

public class CameraSettings : MonoBehaviour
{
	private Transform playerPrefab;

	private Vector3 gizmosPos;

	public static CameraSettings instance;

	[Header("Camera Follow")]
	public Vector3 baseOffset = new Vector3(0f, 5f, -10f);

	public float smoothSpeed = 5f;

	public bool canMove = true;

	[Header("Dynamic Zoom")]
	public float zoomSpeed = 5f;

	public float minZoom = 5f;

	public float maxZoom = 15f;

	public float zoomLimiter = 20f;

	private void Awake()
	{
		if (instance == null)
		{
			instance = this;
			return;
		}
		Debug.LogWarning("Multiple CameraSettings instances detected! Destroying duplicate.");
		Object.Destroy(base.gameObject);
	}

	private void Start()
	{
		StartCoroutine(CameraStartDelay());
	}

	private void LateUpdate()
	{
		if (PlayerManager.instance == null || PlayerManager.instance.playersList.Count == 0 || !canMove)
		{
			return;
		}
		if (PlayerManager.instance.playersList.Count == 1)
		{
			if (playerPrefab != null)
			{
				Vector3 b = playerPrefab.position + baseOffset;
				Vector3 position = Vector3.Lerp(base.transform.position, b, smoothSpeed * Time.deltaTime);
				base.transform.position = position;
			}
			return;
		}
		Vector3 vector = (gizmosPos = FindCenter());
		float num = Mathf.Clamp(GetGreatestDistance(), minZoom, maxZoom);
		if (num < maxZoom - 0.1f)
		{
			Vector3 b2 = vector + baseOffset.normalized * num;
			Vector3 position2 = Vector3.Lerp(base.transform.position, b2, smoothSpeed * Time.deltaTime);
			base.transform.position = position2;
		}
	}

	private IEnumerator CameraStartDelay()
	{
		while (PlayerManager.instance == null || PlayerManager.instance.playersList.Count == 0)
		{
			yield return null;
		}
		playerPrefab = PlayerManager.instance.playersList[0].transform;
	}

	private Vector3 FindCenter()
	{
		Vector3 zero = Vector3.zero;
		foreach (GameObject players in PlayerManager.instance.playersList)
		{
			if (players != null)
			{
				Transform transform = ((players.transform.parent != null) ? players.transform.parent : players.transform);
				zero += transform.position;
			}
		}
		return zero / PlayerManager.instance.playersList.Count;
	}

	private float GetGreatestDistance()
	{
		if (PlayerManager.instance.playersList.Count < 2)
		{
			return 0f;
		}
		Bounds bounds = new Bounds(PlayerManager.instance.playersList[0].transform.position, Vector3.zero);
		foreach (GameObject players in PlayerManager.instance.playersList)
		{
			if (players != null)
			{
				Transform transform = ((players.transform.parent != null) ? players.transform.parent : players.transform);
				bounds.Encapsulate(transform.position);
			}
		}
		return Mathf.Max(bounds.size.x, bounds.size.z);
	}

	private void OnDrawGizmos()
	{
		Gizmos.color = Color.red;
		Gizmos.DrawSphere(gizmosPos, 0.5f);
	}
}
