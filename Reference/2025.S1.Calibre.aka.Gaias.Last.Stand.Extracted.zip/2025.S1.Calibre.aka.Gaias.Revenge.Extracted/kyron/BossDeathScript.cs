using System.Collections;
using UnityEngine;

namespace kyron;

public class BossDeathScript : MonoBehaviour
{
	private GameObject BossPrefab;

	public GameObject WinScreenUI;

	public float WinScreenDelay = 2f;

	private bool bossSpawned;

	private bool hasWon;

	private void Start()
	{
		WinScreenUI.SetActive(value: false);
		BossPrefab = GameObject.FindWithTag("BossBattery");
	}

	private void Update()
	{
		if (!bossSpawned)
		{
			BossPrefab = GameObject.FindWithTag("BossBattery");
			if (BossPrefab != null)
			{
				bossSpawned = true;
			}
		}
		else if (!hasWon && GameObject.FindWithTag("BossBattery") == null)
		{
			hasWon = true;
			StartCoroutine(ShowWinScreenAfterDelay());
		}
	}

	private IEnumerator ShowWinScreenAfterDelay()
	{
		yield return new WaitForSeconds(WinScreenDelay);
		WinScreenUI.SetActive(value: true);
		Time.timeScale = 0f;
	}
}
