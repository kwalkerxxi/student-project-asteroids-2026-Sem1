using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.InputSystem;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

namespace kyron;

public class EscKeyToPause : MonoBehaviour
{
	[SerializeField]
	private GameObject PauseMenu;

	[SerializeField]
	private bool isPaused;

	public static UnityEvent OnPause = new UnityEvent();

	public static UnityEvent OnResume = new UnityEvent();

	public bool isInHomeScreen;

	public bool buttonSelected;

	public Button StartingButton;

	private List<GameObject> items = new List<GameObject>();

	public GameObject PressAnyButtonUI;

	public GameObject PlayerPrefab;

	[SerializeField]
	private InputAction actionPauseMenu;

	private void OnEnable()
	{
		actionPauseMenu.Enable();
		actionPauseMenu.performed += TestUI;
	}

	public void TestUI(InputAction.CallbackContext context)
	{
		Debug.Log("Pause button pressed");
		if (items.Count <= 0)
		{
			StartingButton.Select();
			AddItem(PauseMenu);
			isPaused = true;
			Time.timeScale = 0f;
			OnPause?.Invoke();
		}
		else if (items.Count > 0)
		{
			if (isInHomeScreen && items.Count == 1)
			{
				return;
			}
			items[items.Count - 1].SetActive(value: false);
			items.RemoveAt(items.Count - 1);
			if (items.Count > 0)
			{
				GameObject gameObject = items[items.Count - 1];
				gameObject.SetActive(value: true);
				SelectFirstButton(gameObject);
			}
		}
		if (items.Count <= 0)
		{
			ResumeGame();
		}
	}

	public void OnNextMenuButtonClicked(GameObject nextMenu)
	{
		SelectFirstButton(nextMenu);
	}

	public void SelectFirstButton(GameObject menu)
	{
		StartCoroutine(SelectFirstButtonCoroutine(menu));
	}

	private IEnumerator SelectFirstButtonCoroutine(GameObject menu)
	{
		yield return new WaitForEndOfFrame();
		Button componentInChildren = menu.GetComponentInChildren<Button>(includeInactive: true);
		if (componentInChildren != null && componentInChildren.IsActive() && componentInChildren.interactable)
		{
			componentInChildren.Select();
			yield break;
		}
		Button[] componentsInChildren = menu.GetComponentsInChildren<Button>(includeInactive: true);
		foreach (Button button in componentsInChildren)
		{
			if (button.IsActive() && button.interactable)
			{
				button.Select();
				break;
			}
		}
	}

	private void Start()
	{
		if (PressAnyButtonUI != null)
		{
			PressAnyButtonUI.SetActive(value: true);
		}
		PauseMenu.SetActive(value: false);
		Time.timeScale = 1f;
		isPaused = false;
		if (SceneManager.GetActiveScene().buildIndex == 0)
		{
			isInHomeScreen = true;
			PauseMenu.SetActive(value: true);
			AddItem(PauseMenu);
		}
		else
		{
			isInHomeScreen = false;
		}
	}

	public void Update()
	{
		if (GameObject.FindGameObjectWithTag("Player") != null && PressAnyButtonUI != null)
		{
			PressAnyButtonUI.SetActive(value: false);
		}
	}

	public void AddItem(GameObject newItem)
	{
		if (items.Count > 0)
		{
			items[items.Count - 1].SetActive(value: false);
		}
		items.Add(newItem);
		newItem.SetActive(value: true);
	}

	public void RemoveItem(GameObject removeItem)
	{
		items[items.Count - 1].SetActive(value: false);
		items.RemoveAt(items.Count - 1);
		items[items.Count - 1].SetActive(value: true);
	}

	public void ResumeGame()
	{
		PauseMenu.SetActive(value: false);
		isPaused = false;
		Time.timeScale = 1f;
		items.Clear();
		OnResume?.Invoke();
		items.Clear();
	}
}
