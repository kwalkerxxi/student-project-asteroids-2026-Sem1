using com.cyborgAssets.inspectorButtonPro;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace com.cyborgAssets.internalIBPExample;

public class ExampleInspectorButtonMonoBehavior : MonoBehaviour
{
	public GameObject[] targets;

	[ProButton]
	private string GetGameObjectName()
	{
		return base.gameObject.name;
	}

	[ProButton]
	private void SpecialAttack(float attackPower)
	{
		Debug.Log("perfromed special attack with attackPower = " + attackPower);
	}

	[ProPlayButton]
	private static void LoadScene(int sceneIndex)
	{
		Debug.Log("Loading Scene:" + sceneIndex);
		SceneManager.LoadScene(sceneIndex);
	}

	[ProPlayButton]
	private void DestroyAllEnemies()
	{
		Debug.Log("Destroying " + targets.Length + " enemies");
		for (int i = 0; i < targets.Length; i++)
		{
			Object.Destroy(targets[i]);
		}
	}
}
