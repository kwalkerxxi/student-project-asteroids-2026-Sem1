using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawningEnemny : MonoBehaviour
{
	public GameObject EnemyPrefab;

	public int minEnemiesPerBatch = 3;

	public int maxEnemiesPerBatch = 6;

	public float minSpawnInterval = 3f;

	public float maxSpawnInterval = 5f;

	public float spawnRadius = 2f;

	public int maxEnemiesAlive = 10;

	public Transform spawnPoint;

	public int maxTotalEnemies = 20;

	private int totalEnemiesSpawned;

	public GameObject SpawnParticleEffect;

	private List<GameObject> aliveEnemies = new List<GameObject>();

	private void Start()
	{
		StartCoroutine(SpawnEnemies());
	}

	private IEnumerator SpawnEnemies()
	{
		while (totalEnemiesSpawned < maxTotalEnemies)
		{
			if (aliveEnemies.Count < maxEnemiesAlive)
			{
				float seconds = Random.Range(minSpawnInterval, maxSpawnInterval);
				yield return new WaitForSeconds(seconds);
				int num = maxTotalEnemies - totalEnemiesSpawned;
				int num2 = Random.Range(minEnemiesPerBatch, maxEnemiesPerBatch);
				num2 = Mathf.Min(num2, maxEnemiesAlive - aliveEnemies.Count, num);
				for (int i = 0; i < num2; i++)
				{
					Vector3 vector = Random.insideUnitSphere * spawnRadius;
					vector.y = 0f;
					Vector3 position = spawnPoint.position + vector;
					GameObject gameObject = Object.Instantiate(EnemyPrefab, position, Quaternion.identity);
					aliveEnemies.Add(gameObject);
					Object.Destroy(Object.Instantiate(SpawnParticleEffect, position, Quaternion.identity), 2f);
					totalEnemiesSpawned++;
					minionScript component = gameObject.GetComponent<minionScript>();
					if (component != null)
					{
						component.OnEnemyDeath += HandleEnemyDeath;
					}
				}
			}
			else
			{
				yield return new WaitForSeconds(1f);
			}
		}
	}

	private void HandleEnemyDeath(GameObject enemy)
	{
		if (aliveEnemies.Contains(enemy))
		{
			aliveEnemies.Remove(enemy);
		}
	}
}
