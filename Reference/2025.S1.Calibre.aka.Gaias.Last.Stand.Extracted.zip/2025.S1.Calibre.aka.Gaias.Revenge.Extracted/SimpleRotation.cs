using UnityEngine;

public class SimpleRotation : MonoBehaviour
{
	[SerializeField]
	private float speed = 5f;

	[SerializeField]
	private float height = 0.5f;

	public Vector3 rotationSpeed = new Vector3(0f, 0f, 10f);

	private Vector3 pos;

	private void Start()
	{
		pos = base.transform.position;
	}

	private void Update()
	{
		base.transform.Rotate(rotationSpeed * Time.deltaTime);
		float y = Mathf.Sin(Time.time * speed) * height + pos.y;
		base.transform.position = new Vector3(base.transform.position.x, y, base.transform.position.z);
	}
}
