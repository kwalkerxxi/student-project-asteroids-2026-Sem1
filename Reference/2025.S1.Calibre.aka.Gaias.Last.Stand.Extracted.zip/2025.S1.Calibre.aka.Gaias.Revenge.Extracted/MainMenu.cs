using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenu : MonoBehaviour
{
	[SerializeField]
	private int Easy = 8;

	[SerializeField]
	private int Medium = 12;

	[SerializeField]
	private int Hard = 20;

	public void PlayGame()
	{
		SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
		Time.timeScale = 1f;
		PlayerManager.instance.playersList.Clear();
	}

	public void QuitGame()
	{
		Application.Quit();
	}

	public void ToMainMenu()
	{
		SceneManager.LoadScene(0);
		PlayerManager.instance.playersList.Clear();
		Time.timeScale = 1f;
	}

	public void WinScreen()
	{
		Application.LoadLevel(Application.loadedLevel);
		Time.timeScale = 1f;
	}

	public void EasyMode()
	{
		HoldDifficulty.DifficultyPathLength = Easy;
		SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 2);
	}

	public void MediumMode()
	{
		HoldDifficulty.DifficultyPathLength = Medium;
		SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 2);
	}

	public void HardMode()
	{
		HoldDifficulty.DifficultyPathLength = Hard;
		SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 2);
	}
}
