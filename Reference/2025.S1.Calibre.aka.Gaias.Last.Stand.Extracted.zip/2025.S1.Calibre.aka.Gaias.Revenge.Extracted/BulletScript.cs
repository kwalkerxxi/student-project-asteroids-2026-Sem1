using UnityEngine;

public class BulletScript : MonoBehaviour
{
	public float lifetime = 20f;

	private Rigidbody rb;

	public float bulletSpeed = 10f;

	public float rotationSpeed = 360f;

	public GameObject ImpactParticlePrefab;

	private void Start()
	{
		rb = GetComponent<Rigidbody>();
		Object.Destroy(base.gameObject, lifetime);
	}

	private void FixedUpdate()
	{
		base.transform.Translate(Vector3.forward * bulletSpeed * Time.deltaTime, Space.Self);
		base.transform.Rotate(0f, 0f, rotationSpeed * Time.deltaTime, Space.Self);
	}

	private void OnTriggerEnter(Collider collision)
	{
		if (collision.gameObject.CompareTag("Enemy") || collision.gameObject.CompareTag("Wall"))
		{
			Object.Destroy(Object.Instantiate(ImpactParticlePrefab, base.transform.position, Quaternion.identity), 2f);
			Object.Destroy(base.gameObject);
		}
	}
}
