namespace com.cyborgAssets.internalIBP;

public enum SerializedParameterType : byte
{
	Integer,
	Boolean,
	Float,
	String,
	Color,
	ObjectReference,
	Enum,
	Vector2,
	Vector3,
	Vector4,
	Rect,
	AnimationCurve,
	Bounds,
	Quaternion,
	Vector2Int,
	Vector3Int,
	RectInt,
	BoundsInt
}
