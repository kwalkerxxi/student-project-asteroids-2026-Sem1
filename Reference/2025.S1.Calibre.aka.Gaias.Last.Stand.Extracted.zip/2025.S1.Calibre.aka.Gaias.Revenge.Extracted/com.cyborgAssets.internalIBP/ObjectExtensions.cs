using UnityEngine;

namespace com.cyborgAssets.internalIBP;

public static class ObjectExtensions
{
	public static bool IsPrefab(this Object obj)
	{
		return false;
	}
}
