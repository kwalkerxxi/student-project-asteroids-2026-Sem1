using UnityEngine;

public class SpecialBulletScript : MonoBehaviour
{
	[Header("bullets settings")]
	[SerializeField]
	private float bulletSpeed = 5f;

	[SerializeField]
	private float bulletLife = 1f;

	[SerializeField]
	private GameObject explosionPrefab;

	[SerializeField]
	private int currentSpecialBullet = 4;

	[SerializeField]
	private int MaxSpecialBullet = 10;

	private void Start()
	{
		Invoke("BulletDestroyed", bulletLife);
	}

	private void FixedUpdate()
	{
		base.transform.Translate(Vector3.forward * bulletSpeed * Time.deltaTime);
	}

	private void OnTriggerEnter(Collider collision)
	{
		if (!collision.gameObject.CompareTag("HealingCircle"))
		{
			BulletDestroyed();
		}
	}

	private void BulletDestroyed()
	{
		if (explosionPrefab != null)
		{
			Object.Destroy(Object.Instantiate(explosionPrefab, base.transform.position, Quaternion.identity), 4f);
			base.gameObject.transform.position = new Vector3(0f, -9999f, 0f);
			Object.Destroy(base.gameObject, 2f);
		}
	}
}
