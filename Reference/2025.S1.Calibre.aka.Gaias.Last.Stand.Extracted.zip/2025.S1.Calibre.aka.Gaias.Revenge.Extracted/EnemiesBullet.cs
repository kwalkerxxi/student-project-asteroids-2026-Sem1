using UnityEngine;

public class EnemiesBullet : MonoBehaviour
{
	public float bulletSpeed = 10f;

	public int dmg = 10;

	public float lifeTime = 2f;

	[SerializeField]
	private GameObject collisonParticleEffect;

	private Rigidbody cachedRigidbody;

	private void Start()
	{
		cachedRigidbody = GetComponent<Rigidbody>();
		cachedRigidbody.linearVelocity = base.transform.forward * bulletSpeed;
		Object.Destroy(base.gameObject, lifeTime);
	}

	private void OnCollisionEnter(Collision other)
	{
		if (other.collider.CompareTag("Player"))
		{
			HealthPlayer componentInParent = other.collider.GetComponentInParent<HealthPlayer>();
			if ((object)componentInParent != null)
			{
				componentInParent.TakeDamage(dmg);
				SpawnParticleOnDeath();
			}
		}
		if (other.collider.CompareTag("Wall") || other.gameObject.layer == LayerMask.NameToLayer("Terrain"))
		{
			SpawnParticleOnDeath();
		}
	}

	private void SpawnParticleOnDeath()
	{
		Object.Destroy(Object.Instantiate(collisonParticleEffect, base.transform.position, Quaternion.identity), 2f);
		base.gameObject.transform.position = new Vector3(0f, -9999f, 0f);
		Object.Destroy(base.gameObject, 2f);
	}
}
