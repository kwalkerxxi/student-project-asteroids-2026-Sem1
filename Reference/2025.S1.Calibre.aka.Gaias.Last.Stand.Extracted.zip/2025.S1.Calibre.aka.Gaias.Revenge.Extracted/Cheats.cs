using UnityEngine;
using UnityEngine.InputSystem;

public class Cheats : MonoBehaviour
{
	[SerializeField]
	private InputAction actionGodMode;

	[SerializeField]
	private InputAction actionTeleport;

	[SerializeField]
	private InputAction actionInfiniteAmmo;

	[SerializeField]
	private InputAction actionGameSpeed100;

	[SerializeField]
	private InputAction actionGameSpeed50;

	[SerializeField]
	private InputAction actionGameSpeed25;

	[SerializeField]
	private InputAction actionGameSpeed10;

	[SerializeField]
	private InputAction actionKillPlayer;

	[SerializeField]
	private InputAction actionPlayerSpeedDefault;

	[SerializeField]
	private InputAction actionPlayerSpeedDouble;

	private HealthPlayer healthPlayer;

	public GameObject PlayerPrefab;

	private int normalLayer = 3;

	private int invincibilityLayer = 12;

	private int currentLocationIndex;

	private int MaxLocationIndex = 3;

	public GameObject spawnSpot;

	public GameObject spawnSpot2;

	public GameObject spawnSpot3;

	public GameObject spawnSpot4;

	private PlayerControls playerControls;

	private float movementDefault;

	private void OnEnable()
	{
		actionGodMode.Enable();
		actionGodMode.performed += GodMode;
		actionTeleport.Enable();
		actionTeleport.performed += DoTeleport;
		actionInfiniteAmmo.Enable();
		actionInfiniteAmmo.performed += InfiniteAmmo;
		actionGameSpeed100.Enable();
		actionGameSpeed100.performed += GameSpeed100;
		actionGameSpeed50.Enable();
		actionGameSpeed50.performed += GameSpeed50;
		actionGameSpeed25.Enable();
		actionGameSpeed25.performed += GameSpeed25;
		actionGameSpeed10.Enable();
		actionGameSpeed10.performed += GameSpeed10;
		healthPlayer = GetComponent<HealthPlayer>();
		actionKillPlayer.Enable();
		actionKillPlayer.performed += KillPlayer;
		playerControls = GetComponent<PlayerControls>();
		movementDefault = playerControls.moveSpeed;
		actionPlayerSpeedDefault.Enable();
		actionPlayerSpeedDefault.performed += MoveSpeedDefault;
		actionPlayerSpeedDouble.Enable();
		actionPlayerSpeedDouble.performed += MoveSpeedDouble;
	}

	private void InfiniteAmmo(InputAction.CallbackContext context)
	{
	}

	public void GameSpeed50(InputAction.CallbackContext context)
	{
		Time.timeScale = 0.5f;
	}

	public void GameSpeed25(InputAction.CallbackContext context)
	{
		Time.timeScale = 0.25f;
	}

	public void GameSpeed10(InputAction.CallbackContext context)
	{
		Time.timeScale = 0.1f;
	}

	public void GameSpeed100(InputAction.CallbackContext context)
	{
		Time.timeScale = 1f;
	}

	public void MoveSpeedDefault(InputAction.CallbackContext context)
	{
		playerControls.moveSpeed = movementDefault;
	}

	public void MoveSpeedDouble(InputAction.CallbackContext context)
	{
		playerControls.moveSpeed = movementDefault * 2f;
	}

	private void DoTeleport(InputAction.CallbackContext context)
	{
		PlayerPrefab.transform.position = spawnSpot.transform.position;
		switch (currentLocationIndex)
		{
		case 0:
			PlayerPrefab.transform.position = spawnSpot.transform.position;
			Debug.Log("Actual Player pos : " + PlayerPrefab.transform.position.ToString());
			Debug.Log("Position targeted : " + spawnSpot.transform.position.ToString());
			break;
		case 1:
			PlayerPrefab.transform.position = spawnSpot2.transform.position;
			Debug.Log("Actual Player pos : " + PlayerPrefab.transform.position.ToString());
			Debug.Log("Position targeted : " + spawnSpot2.transform.position.ToString());
			break;
		case 2:
			PlayerPrefab.transform.position = spawnSpot3.transform.position;
			Debug.Log("Actual Player pos : " + PlayerPrefab.transform.position.ToString());
			Debug.Log("Position targeted : " + spawnSpot3.transform.position.ToString());
			break;
		case 3:
			PlayerPrefab.transform.position = spawnSpot4.transform.position;
			Debug.Log("Actual Player pos : " + PlayerPrefab.transform.position.ToString());
			Debug.Log("Position targeted : " + spawnSpot4.transform.position.ToString());
			break;
		}
		currentLocationIndex++;
		if (currentLocationIndex > MaxLocationIndex)
		{
			currentLocationIndex = 0;
		}
	}

	public void KillPlayer(InputAction.CallbackContext context)
	{
		healthPlayer.Die();
	}

	private void GodMode(InputAction.CallbackContext context)
	{
		if (!(PlayerPrefab == null))
		{
			int newLayer = ((PlayerPrefab.layer == invincibilityLayer) ? normalLayer : invincibilityLayer);
			SetLayerRecursively(PlayerPrefab, newLayer);
		}
	}

	private void SetLayerRecursively(GameObject obj, int newLayer)
	{
		obj.layer = newLayer;
		foreach (Transform item in obj.transform)
		{
			SetLayerRecursively(item.gameObject, newLayer);
		}
	}
}
