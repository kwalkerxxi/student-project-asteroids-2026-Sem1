using Unity.Cinemachine;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace Common.Useful;

public class RelativeMovementUsingCameraAxes : MonoBehaviour
{
	[SerializeField]
	private float movementSpeed = 8f;

	private void Start()
	{
		Camera.main.gameObject.AddComponent<CinemachineBrain>();
	}

	private void Update()
	{
		MovePlayerRelativeToCamera();
		RestartInput();
		QuitInput();
	}

	private void RestartInput()
	{
		if (Input.GetKeyDown(KeyCode.R))
		{
			SceneManager.LoadScene(SceneManager.GetActiveScene().name);
		}
	}

	private void QuitInput()
	{
		if (Input.GetKeyDown(KeyCode.Escape) || Input.GetKeyDown(KeyCode.Q))
		{
			Application.Quit();
		}
	}

	private void MovePlayerRelativeToCamera()
	{
		float axis = Input.GetAxis("Vertical");
		float axis2 = Input.GetAxis("Horizontal");
		Vector3 forward = Camera.main.transform.forward;
		Vector3 right = Camera.main.transform.right;
		forward.y = 0f;
		right.y = 0f;
		forward = forward.normalized;
		right = right.normalized;
		Vector3 vector = axis * forward;
		Vector3 vector2 = axis2 * right;
		Vector3 vector3 = vector + vector2;
		if (vector3.magnitude > 0.1f)
		{
			RotateToFaceMovementVector(vector3);
			base.transform.Translate(vector3 * movementSpeed * Time.deltaTime, Space.World);
		}
	}

	private void RotateToFaceMovementVector(Vector3 vector)
	{
		Quaternion b = Quaternion.LookRotation(vector);
		base.transform.rotation = Quaternion.Slerp(base.transform.rotation, b, Time.deltaTime * 10f);
	}
}
