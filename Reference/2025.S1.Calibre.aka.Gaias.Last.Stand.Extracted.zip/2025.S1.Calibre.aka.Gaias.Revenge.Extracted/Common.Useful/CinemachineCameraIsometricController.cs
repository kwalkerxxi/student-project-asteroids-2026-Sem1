using TMPro;
using Unity.Cinemachine;
using UnityEngine;
using UnityEngine.UI;

namespace Common.Useful;

[RequireComponent(typeof(CinemachineCamera), typeof(CinemachineFollow), typeof(CinemachineRotationComposer))]
public class CinemachineCameraIsometricController : MonoBehaviour
{
	[SerializeField]
	private Slider fovSlider;

	[SerializeField]
	private Slider offsetSlider;

	[SerializeField]
	private float yOffset = 30f;

	[SerializeField]
	private float startingFov = 60f;

	private TextMeshProUGUI fovTextbox;

	private TextMeshProUGUI offsetTextbox;

	private Vector3 currentOffsetValue = Vector3.zero;

	private Vector3 isometricOffset = new Vector3(0.5f, 1f, -0.5f);

	private float currentFov = 60f;

	private CinemachineCamera cinemachineCameraComponent;

	private CinemachineFollow cinemachineFollowComponent;

	private void Awake()
	{
		cinemachineCameraComponent = GetComponent<CinemachineCamera>();
		cinemachineCameraComponent.Lens.FieldOfView = startingFov;
		cinemachineFollowComponent = GetComponent<CinemachineFollow>();
		cinemachineFollowComponent.TrackerSettings.PositionDamping = Vector3.zero;
		fovSlider.minValue = 10f;
		fovSlider.maxValue = 160f;
		currentFov = startingFov;
		fovSlider.value = currentFov;
		fovTextbox = fovSlider.GetComponentInChildren<TextMeshProUGUI>();
		offsetSlider.minValue = 2f;
		offsetSlider.maxValue = 100f;
		currentOffsetValue = isometricOffset * yOffset;
		offsetSlider.value = yOffset;
		offsetTextbox = offsetSlider.GetComponentInChildren<TextMeshProUGUI>();
	}

	private void Start()
	{
		UpdateDisplays();
	}

	private void OnEnable()
	{
		fovSlider.onValueChanged.AddListener(OnFovSliderChanged);
		offsetSlider.onValueChanged.AddListener(OnOffsetSliderChanged);
	}

	private void OnDisable()
	{
		fovSlider.onValueChanged.RemoveListener(OnFovSliderChanged);
		offsetSlider.onValueChanged.RemoveListener(OnOffsetSliderChanged);
	}

	private void OnFovSliderChanged(float valueOfSlider)
	{
		currentFov = valueOfSlider;
		currentFov = Mathf.Clamp(currentFov, 10f, 160f);
		cinemachineCameraComponent.Lens.FieldOfView = currentFov;
		UpdateDisplays();
	}

	private void OnOffsetSliderChanged(float valueOfSlider)
	{
		yOffset = valueOfSlider;
		yOffset = Mathf.Clamp(yOffset, 3f, 100f);
		currentOffsetValue = isometricOffset * yOffset;
		cinemachineFollowComponent.FollowOffset = currentOffsetValue;
		UpdateDisplays();
	}

	private void UpdateDisplays()
	{
		fovTextbox.text = "FOV - " + currentFov.ToString("N0");
		offsetTextbox.text = "Offset - X:" + currentOffsetValue.x.ToString("N0") + "  Y:" + currentOffsetValue.y.ToString("N0") + "  Z:" + currentOffsetValue.z.ToString("N0");
	}
}
