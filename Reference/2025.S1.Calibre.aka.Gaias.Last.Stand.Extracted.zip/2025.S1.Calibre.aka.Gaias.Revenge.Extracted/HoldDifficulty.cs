using UnityEngine;

public class HoldDifficulty : MonoBehaviour
{
	public static int DifficultyPathLength;
}
