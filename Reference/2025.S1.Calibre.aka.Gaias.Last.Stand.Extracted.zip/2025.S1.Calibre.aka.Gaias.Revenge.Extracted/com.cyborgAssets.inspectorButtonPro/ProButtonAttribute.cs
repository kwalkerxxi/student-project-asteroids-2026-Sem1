using System;
using com.cyborgAssets.internalIBP;
using UnityEngine;

namespace com.cyborgAssets.inspectorButtonPro;

public class ProButtonAttribute : Attribute, IButtonAttribute
{
	public string Error => "Selected object is a prefab, use [Prefab] tag to execute method on a prefab";

	public bool PerformCheck(UnityEngine.Object obj)
	{
		return !obj.IsPrefab();
	}
}
