using System;
using com.cyborgAssets.internalIBP;
using UnityEngine;

namespace com.cyborgAssets.inspectorButtonPro;

public class ProPlayButtonAttribute : Attribute, IButtonAttribute
{
	public string Error => "Unity Editor is not running, press the unity play button - or use the [ProButton] attribute to execute methods in Edit mode";

	public bool PerformCheck(UnityEngine.Object obj)
	{
		if (!obj.IsPrefab())
		{
			return Application.isPlaying;
		}
		return false;
	}
}
