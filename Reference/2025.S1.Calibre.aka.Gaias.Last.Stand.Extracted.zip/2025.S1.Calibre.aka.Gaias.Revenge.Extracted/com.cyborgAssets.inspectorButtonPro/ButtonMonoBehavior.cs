using UnityEngine;

namespace com.cyborgAssets.inspectorButtonPro;

public class ButtonMonoBehavior : MonoBehaviour
{
}
