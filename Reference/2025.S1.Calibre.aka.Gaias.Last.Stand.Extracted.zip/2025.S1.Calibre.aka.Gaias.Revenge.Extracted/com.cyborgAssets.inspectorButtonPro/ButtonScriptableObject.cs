using UnityEngine;

namespace com.cyborgAssets.inspectorButtonPro;

public class ButtonScriptableObject : ScriptableObject
{
}
