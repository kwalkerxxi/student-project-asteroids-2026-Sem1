using UnityEngine;

public class CameraBound : MonoBehaviour
{
	public float padding = 0.05f;

	private Camera cam;

	private Rigidbody rb;

	private void Start()
	{
		cam = Camera.main;
		if (cam == null)
		{
			Debug.LogError("No MainCamera found! Please tag your camera as 'MainCamera'.");
		}
	}

	private void FixedUpdate()
	{
		if (!(cam == null))
		{
			Vector3 position = base.transform.position;
			Vector3 position2 = cam.WorldToViewportPoint(position);
			position2.x = Mathf.Clamp(position2.x, 0f + padding, 1f - padding);
			position2.y = Mathf.Clamp(position2.y, 0f + padding, 1f - padding);
			Vector3 vector = cam.ViewportToWorldPoint(position2);
			base.transform.position = new Vector3(vector.x, base.transform.position.y, vector.z);
		}
	}
}
