using UnityEngine;

public class ExplosionScript : MonoBehaviour
{
	[SerializeField]
	private float explosionLife = 0.5f;

	[SerializeField]
	private float explosionDMG = 30f;

	private void Start()
	{
		Object.Destroy(base.gameObject, explosionLife);
	}

	private void OnTriggerEnter(Collider other)
	{
		if (other.CompareTag("Enemy") || other.CompareTag("Wall"))
		{
			Object.Destroy(other.gameObject);
		}
	}
}
