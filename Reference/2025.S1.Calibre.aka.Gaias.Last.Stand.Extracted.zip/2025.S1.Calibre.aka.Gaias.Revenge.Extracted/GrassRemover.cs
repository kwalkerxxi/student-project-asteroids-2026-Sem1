using UnityEngine;

public class GrassRemover : MonoBehaviour
{
	public int detailLayerIndex;

	public float radius = 5f;

	private Terrain terrain;

	private TerrainData terrainData;

	private int[,] originalDetails;

	private int detailWidth;

	private int detailHeight;

	private void Start()
	{
		terrain = Terrain.activeTerrain;
		if (terrain == null)
		{
			Debug.LogError("No active Terrain found!");
			return;
		}
		terrainData = terrain.terrainData;
		detailWidth = terrainData.detailWidth;
		detailHeight = terrainData.detailHeight;
		originalDetails = terrainData.GetDetailLayer(0, 0, detailWidth, detailHeight, detailLayerIndex);
		RemoveGrassArea();
	}

	private void RemoveGrassArea()
	{
		Vector3 position = terrain.transform.position;
		Vector3 vector = base.transform.position - position;
		int num = Mathf.RoundToInt(vector.x / terrainData.size.x * (float)detailWidth);
		int num2 = Mathf.RoundToInt(vector.z / terrainData.size.z * (float)detailHeight);
		int num3 = Mathf.RoundToInt(radius / terrainData.size.x * (float)detailWidth);
		int num4 = Mathf.Clamp(num - num3, 0, detailWidth - 1);
		int num5 = Mathf.Clamp(num + num3, 0, detailWidth - 1);
		int num6 = Mathf.Clamp(num2 - num3, 0, detailHeight - 1);
		int num7 = Mathf.Clamp(num2 + num3, 0, detailHeight - 1);
		int num8 = num5 - num4 + 1;
		int num9 = num7 - num6 + 1;
		int[,] array = new int[num9, num8];
		for (int i = 0; i < num9; i++)
		{
			for (int j = 0; j < num8; j++)
			{
				array[i, j] = originalDetails[i + num6, j + num4];
			}
		}
		for (int k = 0; k < num9; k++)
		{
			for (int l = 0; l < num8; l++)
			{
				int num10 = l + num4 - num;
				int num11 = k + num6 - num2;
				if (Mathf.Sqrt(num10 * num10 + num11 * num11) <= (float)num3)
				{
					array[k, l] = 0;
				}
			}
		}
		terrainData.SetDetailLayer(num4, num6, detailLayerIndex, array);
	}

	private void OnDisable()
	{
		if (terrainData != null && originalDetails != null)
		{
			terrainData.SetDetailLayer(0, 0, detailLayerIndex, originalDetails);
		}
	}

	private void OnDestroy()
	{
		OnDisable();
	}
}
