using UnityEngine;
using UnityEngine.UI;

public class CameraMoveScript : MonoBehaviour
{
	public Transform[] cameraPositions;

	public float moveSpeed = 5f;

	public Button nextButton;

	public Button prevButton;

	private int currentIndex;

	private bool isMoving;

	private void Start()
	{
		if (cameraPositions.Length != 0)
		{
			base.transform.position = cameraPositions[currentIndex].position;
			base.transform.rotation = cameraPositions[currentIndex].rotation;
			nextButton.onClick.AddListener(MoveToNextPosition);
			prevButton.onClick.AddListener(MoveToPreviousPosition);
		}
	}

	private void Update()
	{
		if (isMoving)
		{
			Transform transform = cameraPositions[currentIndex];
			base.transform.position = Vector3.Lerp(base.transform.position, transform.position, Time.deltaTime * moveSpeed);
			base.transform.rotation = Quaternion.Slerp(base.transform.rotation, transform.rotation, Time.deltaTime * moveSpeed);
			if (Vector3.Distance(base.transform.position, transform.position) < 0.01f && Quaternion.Angle(base.transform.rotation, transform.rotation) < 1f)
			{
				base.transform.position = transform.position;
				base.transform.rotation = transform.rotation;
				isMoving = false;
			}
		}
	}

	public void MoveToNextPosition()
	{
		if (currentIndex < cameraPositions.Length - 1)
		{
			currentIndex++;
			isMoving = true;
		}
	}

	public void MoveToPreviousPosition()
	{
		if (currentIndex > 0)
		{
			currentIndex--;
			isMoving = true;
		}
	}
}
