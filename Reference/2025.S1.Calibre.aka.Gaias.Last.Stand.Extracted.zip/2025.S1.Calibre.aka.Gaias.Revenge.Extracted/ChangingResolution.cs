using UnityEngine;

public class ChangingResolution : MonoBehaviour
{
	public void Default_1920_1080()
	{
		Screen.SetResolution(1920, 1080, fullscreen: true, 60);
	}

	public void Long_1000_600()
	{
		Screen.SetResolution(1000, 600, fullscreen: false, 60);
	}

	public void Square_300_300()
	{
		Screen.SetResolution(300, 300, fullscreen: false, 60);
	}

	public void FullScreen()
	{
		Screen.fullScreen = !Screen.fullScreen;
	}
}
