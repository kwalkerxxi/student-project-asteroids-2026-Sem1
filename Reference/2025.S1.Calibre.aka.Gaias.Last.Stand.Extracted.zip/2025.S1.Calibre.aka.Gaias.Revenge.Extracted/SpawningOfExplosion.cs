using UnityEngine;

public class SpawningOfExplosion : MonoBehaviour
{
	public GameObject ExplosionEffect;

	public Vector3 explosionScale = Vector3.one;

	public void SpawnExplosionOnClick()
	{
		GameObject obj = Object.Instantiate(ExplosionEffect, base.transform.position, base.transform.rotation);
		obj.transform.localScale = explosionScale;
		Object.Destroy(obj, 2f);
	}
}
