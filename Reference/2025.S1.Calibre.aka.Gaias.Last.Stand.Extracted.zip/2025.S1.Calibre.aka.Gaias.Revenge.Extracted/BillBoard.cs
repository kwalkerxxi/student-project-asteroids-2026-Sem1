using UnityEngine;

public class BillBoard : MonoBehaviour
{
	public Transform cam;

	private void LateUpdate()
	{
		base.transform.LookAt(base.transform.position + cam.forward);
	}
}
