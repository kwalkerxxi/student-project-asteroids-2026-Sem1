using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class HealthPlayer : MonoBehaviour
{
	[Header("Health System")]
	public float maxHealth = 100f;

	public float currentHealth;

	public float invulnerabilityTime = 1f;

	private bool isInvulnerable;

	[Header("Respawn System")]
	public Transform spawnPoint;

	public GameObject gameOverText;

	private bool isDead;

	private PlayerControls playerControls;

	private HealingAbility HealingAbilityScript;

	[Header("Death")]
	public float DeathDelay;

	private PlayerInput playerInput;

	[SerializeField]
	private float explosionForce_X = 300f;

	[SerializeField]
	private Vector3 explosionForce_Y;

	[SerializeField]
	private float explosionForce_Z = 5f;

	[SerializeField]
	private Button SelectionButton;

	[Header("Healing UI")]
	private Image Player1HeatlhBar;

	private UIControls hud;

	[Header("Healing UI")]
	public Material damageOverlayMaterial;

	[Header("Damage Flash")]
	private Renderer[] renderers;

	private Dictionary<Renderer, Material[]> originalMaterials = new Dictionary<Renderer, Material[]>();

	[SerializeField]
	private float timeBetweenFlashes = 0.1f;

	[SerializeField]
	private GolemAnimHandler animHandler;

	private void Start()
	{
		HealingAbilityScript = GetComponent<HealingAbility>();
		Player1HeatlhBar = GameObject.Find("HealthBar").GetComponent<Image>();
		renderers = GetComponentsInChildren<Renderer>();
		playerInput = GetComponent<PlayerInput>();
		Renderer[] array = renderers;
		foreach (Renderer renderer in array)
		{
			originalMaterials[renderer] = renderer.materials;
		}
		if (gameOverText == null)
		{
			gameOverText = Resources.FindObjectsOfTypeAll<GameObject>().FirstOrDefault((GameObject go) => go.name == "DeathScreen" && go.scene.IsValid());
			if (gameOverText == null)
			{
				Object.Destroy(GameObject.Find("PlayerHolder(Clone)"));
			}
			hud = GetComponentInChildren<UIControls>();
			currentHealth = maxHealth;
		}
		currentHealth = maxHealth;
		playerControls = GetComponent<PlayerControls>();
	}

	private void Update()
	{
	}

	public void TakeDamage(float damage)
	{
		if (!isInvulnerable && !isDead)
		{
			animHandler.TriggerHit();
			currentHealth -= damage;
			if (hud != null)
			{
				hud.UpdateHealth(currentHealth, maxHealth);
			}
			StartCoroutine(Invulnerability());
			if (currentHealth <= 0f)
			{
				Die();
			}
		}
	}

	private IEnumerator Invulnerability()
	{
		isInvulnerable = true;
		yield return StartCoroutine(BlinkingFlash());
		isInvulnerable = false;
	}

	private IEnumerator BlinkingFlash()
	{
		int flashes = Mathf.FloorToInt(invulnerabilityTime / timeBetweenFlashes);
		bool showOverlay = false;
		Renderer[] array;
		for (int i = 0; i < flashes; i++)
		{
			showOverlay = !showOverlay;
			array = renderers;
			foreach (Renderer renderer in array)
			{
				renderer.materials = (showOverlay ? renderer.materials.Concat(new Material[1] { damageOverlayMaterial }).ToArray() : originalMaterials[renderer]);
			}
			yield return new WaitForSeconds(timeBetweenFlashes);
		}
		array = renderers;
		foreach (Renderer renderer2 in array)
		{
			renderer2.materials = originalMaterials[renderer2];
		}
	}

	public void ExplodeIntoRocks()
	{
		Transform[] componentsInChildren = GetComponentsInChildren<Transform>();
		foreach (Transform transform in componentsInChildren)
		{
			if (!(transform == base.transform))
			{
				if (!transform.TryGetComponent<Rigidbody>(out var component))
				{
					component = transform.gameObject.AddComponent<Rigidbody>();
				}
				if (!transform.TryGetComponent<Collider>(out var component2))
				{
					component2 = transform.gameObject.AddComponent<MeshCollider>();
				}
				if (component2 is MeshCollider meshCollider)
				{
					meshCollider.convex = true;
				}
				transform.parent = null;
				component.isKinematic = false;
				component.useGravity = true;
				component.AddExplosionForce(explosionForce_X, explosionForce_Y, explosionForce_Z);
			}
		}
	}

	public void Die()
	{
		isDead = true;
		Time.timeScale = 0.5f;
		animHandler.SetIsDead(dead: true);
		if (PlayerManager.instance != null)
		{
			PlayerManager.instance.playersList.Clear();
		}
		StartCoroutine(ShowWinScreenAfterDelay());
	}

	private IEnumerator ShowWinScreenAfterDelay()
	{
		GetComponent<PlayerControls>().enabled = false;
		GetComponent<HealingAbility>().enabled = false;
		playerInput.actions["SpecialAttack"].Disable();
		playerInput.actions["Attack"].Disable();
		playerInput.actions["HealingAbility"].Disable();
		playerInput.actions["PauseMenu"].Disable();
		yield return new WaitForSeconds(DeathDelay);
		gameOverText.SetActive(value: true);
		SelectionButton = GameObject.Find("DeathRestart").GetComponent<Button>();
		Debug.Log("Active" + SelectionButton);
		SelectionButton.gameObject.SetActive(value: true);
		SelectionButton.Select();
		Time.timeScale = 0f;
	}

	public void RestartLevel()
	{
		SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
		gameOverText.SetActive(value: false);
		PlayerManager.instance.playersList.Clear();
	}
}
