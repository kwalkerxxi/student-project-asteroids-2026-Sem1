using Unity.Cinemachine;
using UnityEngine;
using UnityEngine.Events;

[RequireComponent(typeof(BoxCollider), typeof(Rigidbody))]
public class ZoneIdAndEvents : MonoBehaviour
{
	private Rigidbody zoneRigidbody;

	private BoxCollider zoneBoxCollider;

	[TagField]
	[SerializeField]
	private string tagThatActivatesTriggers = "Player";

	public UnityEvent OnEnteredZone;

	public UnityEvent OnStayInZone;

	public UnityEvent OnExitZone;

	[field: SerializeField]
	public int ZoneID { get; set; }

	public static void AttachAsChild(Transform objectToAddAsChildTo, int idAssigned, Vector3 boxColliderSize)
	{
		GameObject obj = new GameObject("Zone events");
		obj.transform.SetParent(objectToAddAsChildTo, worldPositionStays: false);
		obj.AddComponent<ZoneIdAndEvents>().Initilize(idAssigned, boxColliderSize);
	}

	private void Awake()
	{
		zoneRigidbody = GetComponent<Rigidbody>();
		zoneBoxCollider = GetComponent<BoxCollider>();
	}

	public void Initilize(int idAssigned, Vector3 boxColliderSize)
	{
		ZoneID = idAssigned;
		zoneRigidbody.isKinematic = true;
		zoneBoxCollider.isTrigger = true;
		zoneBoxCollider.size = boxColliderSize;
	}

	private void OnTriggerEnter(Collider other)
	{
		if (other.transform.CompareTag(tagThatActivatesTriggers))
		{
			OnEnteredZone?.Invoke();
		}
	}

	private void OnTriggerStay(Collider other)
	{
		if (other.transform.CompareTag(tagThatActivatesTriggers))
		{
			OnStayInZone?.Invoke();
		}
	}

	private void OnTriggerExit(Collider other)
	{
		if (other.transform.CompareTag(tagThatActivatesTriggers))
		{
			OnExitZone?.Invoke();
		}
	}
}
