using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class UIControls : MonoBehaviour
{
	[Header("UI References")]
	public Image healthBar;

	public TextMeshProUGUI ammoText;

	public CanvasGroup canvasGroup;

	[Header("Healing UI")]
	public Image healingCooldownFill;

	public TextMeshProUGUI healingCooldownText;

	private Coroutine hideCoroutine;

	private Coroutine fadeCoroutine;

	[Header("Fade Settings")]
	[SerializeField]
	private float fadeDuration = 0.5f;

	[SerializeField]
	private float fadeDelay = 2f;

	private bool isFadingNow;

	private void Awake()
	{
		canvasGroup = GetComponentInChildren<CanvasGroup>();
		if (canvasGroup == null)
		{
			Debug.LogWarning("HUDController: CanvasGroup not found. Make sure your Canvas has a CanvasGroup component.");
		}
	}

	private void Start()
	{
		ShowHUDInstant();
	}

	public void UpdateHealth(float current, float max)
	{
		if (healthBar != null)
		{
			healthBar.fillAmount = current / max;
		}
		TriggerHUDVisibility();
	}

	public void UpdateAmmo(int current, int max)
	{
		if (ammoText != null)
		{
			ammoText.text = $"{current}";
		}
		TriggerHUDVisibility();
	}

	private void TriggerHUDVisibility()
	{
		if (!isFadingNow)
		{
			FadeHUD(fadeIn: true);
			if (hideCoroutine != null)
			{
				StopCoroutine(hideCoroutine);
			}
			hideCoroutine = StartCoroutine(HideAfterDelay());
		}
	}

	private void ShowHUD()
	{
		if (canvasGroup != null)
		{
			canvasGroup.alpha = 1f;
			canvasGroup.blocksRaycasts = true;
		}
	}

	private IEnumerator HideAfterDelay()
	{
		yield return new WaitForSeconds(fadeDelay);
		FadeHUD(fadeIn: false);
	}

	public void UpdateHealingCooldown(float timeRemaining, float maxTime, bool triggerVisibility = true)
	{
		if (healingCooldownFill != null)
		{
			healingCooldownFill.fillAmount = timeRemaining / maxTime;
		}
		if (healingCooldownText != null)
		{
			healingCooldownText.text = Mathf.CeilToInt(timeRemaining).ToString();
			Color color = healingCooldownText.color;
			color.a = ((timeRemaining > 0f) ? 1f : 0f);
			healingCooldownText.color = color;
		}
		if (triggerVisibility)
		{
			TriggerHUDVisibility();
		}
	}

	private void FadeHUD(bool fadeIn)
	{
		if (!(canvasGroup == null))
		{
			if (fadeCoroutine != null)
			{
				StopCoroutine(fadeCoroutine);
			}
			fadeCoroutine = StartCoroutine(FadeCoroutine(fadeIn));
		}
	}

	private IEnumerator FadeCoroutine(bool fadeIn)
	{
		isFadingNow = true;
		float start = canvasGroup.alpha;
		float end = (fadeIn ? 1f : 0f);
		float elapsed = 0f;
		canvasGroup.blocksRaycasts = true;
		while (elapsed < fadeDuration)
		{
			canvasGroup.alpha = Mathf.Lerp(start, end, elapsed / fadeDuration);
			elapsed += Time.unscaledDeltaTime;
			yield return null;
		}
		canvasGroup.alpha = end;
		canvasGroup.blocksRaycasts = fadeIn;
		isFadingNow = false;
	}

	private void ShowHUDInstant()
	{
		if (canvasGroup != null)
		{
			canvasGroup.alpha = 1f;
			canvasGroup.blocksRaycasts = true;
		}
	}
}
