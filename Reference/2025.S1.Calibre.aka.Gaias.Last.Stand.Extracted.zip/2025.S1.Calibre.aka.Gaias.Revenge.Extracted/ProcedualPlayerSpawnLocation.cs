using UnityEngine;

public class ProcedualPlayerSpawnLocation : MonoBehaviour
{
	public GameObject PlayerPrefab;

	public GameObject PlayerLocationToSpawn;

	private void Start()
	{
		PlayerPrefab.transform.position = PlayerLocationToSpawn.transform.position;
		PlayerPrefab.transform.rotation = PlayerLocationToSpawn.transform.rotation;
	}

	private void Update()
	{
	}
}
