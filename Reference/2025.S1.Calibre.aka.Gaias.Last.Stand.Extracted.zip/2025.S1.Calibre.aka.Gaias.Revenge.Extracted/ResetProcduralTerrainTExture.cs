using UnityEngine;

public class ResetProcduralTerrainTExture : MonoBehaviour
{
	private Terrain terrain;

	private TerrainData originalTerrainData;

	private TerrainData runtimeTerrainData;

	private float[,,] originalAlphamaps;

	private void Awake()
	{
		terrain = Terrain.activeTerrain;
		if (terrain == null)
		{
			Debug.LogError("No active terrain found!");
			return;
		}
		originalTerrainData = terrain.terrainData;
		runtimeTerrainData = Object.Instantiate(originalTerrainData);
		terrain.terrainData = runtimeTerrainData;
		originalAlphamaps = runtimeTerrainData.GetAlphamaps(0, 0, runtimeTerrainData.alphamapWidth, runtimeTerrainData.alphamapHeight);
	}

	private void OnDisable()
	{
		RestoreOriginalTerrainData();
	}

	private void OnDestroy()
	{
		RestoreOriginalTerrainData();
	}

	private void RestoreOriginalTerrainData()
	{
		if (terrain != null && originalTerrainData != null)
		{
			terrain.terrainData = originalTerrainData;
			Debug.Log("TerrainData restored to original asset.");
		}
	}
}
