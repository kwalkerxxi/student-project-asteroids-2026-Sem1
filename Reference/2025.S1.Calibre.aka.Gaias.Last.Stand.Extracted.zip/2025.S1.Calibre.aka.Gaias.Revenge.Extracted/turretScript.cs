using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.UI;

public class turretScript : MonoBehaviour
{
	[Header("Health System")]
	public float MaxLife = 100f;

	private float currentHealth;

	public Slider healthBar;

	public Transform healthBarPosition;

	[Header("Rocket System")]
	public GameObject rocketPrefab;

	public Transform[] firePoints;

	public float fireDelay;

	public float detectRange;

	private Transform player;

	private bool isFiring;

	private bool playerInRange;

	[SerializeField]
	private Collider[] allPlayerCollidersFoundWithinDetectionRange;

	[SerializeField]
	private List<Transform> allPlayersWithinRange;

	[SerializeField]
	private LayerMask playerLayer = -1;

	public GameObject DeathExplosionEffect;

	public List<Collider> collidersAppliedDamage = new List<Collider>();

	private void Start()
	{
		currentHealth = MaxLife;
		if (healthBar != null)
		{
			healthBar.gameObject.SetActive(value: true);
			healthBar.maxValue = MaxLife;
			healthBar.value = currentHealth;
		}
		player = GameObject.FindGameObjectWithTag("Player")?.transform;
	}

	private Transform FindNearestPlayer()
	{
		Transform result = null;
		float num = float.PositiveInfinity;
		Vector3 position = base.transform.position;
		foreach (Transform item in allPlayersWithinRange)
		{
			float num2 = Vector3.Distance(position, item.position);
			if (num2 < num)
			{
				num = num2;
				result = item;
			}
		}
		return result;
	}

	private Transform FindNearestPlayerLinqVersion()
	{
		return allPlayersWithinRange.OrderBy((Transform t) => Vector3.Distance(base.transform.position, t.position)).FirstOrDefault();
	}

	private void Update()
	{
		allPlayerCollidersFoundWithinDetectionRange = Physics.OverlapSphere(base.transform.position, detectRange, playerLayer);
		if (allPlayerCollidersFoundWithinDetectionRange.Length == 0)
		{
			return;
		}
		allPlayersWithinRange.Clear();
		Collider[] array = allPlayerCollidersFoundWithinDetectionRange;
		for (int i = 0; i < array.Length; i++)
		{
			if (array[i].TryGetComponent<PlayerInput>(out var component) && !allPlayersWithinRange.Contains(component.transform))
			{
				allPlayersWithinRange.Add(component.transform);
			}
		}
		player = FindNearestPlayerLinqVersion();
		if (!(player == null))
		{
			if (!isFiring)
			{
				StartCoroutine(FireRockets());
			}
			if (healthBar != null)
			{
				healthBar.transform.position = healthBarPosition.position;
			}
		}
	}

	private IEnumerator FireRockets()
	{
		isFiring = true;
		for (int i = 0; i < firePoints.Length; i++)
		{
			Object.Instantiate(rocketPrefab, firePoints[i].position, firePoints[i].rotation);
			yield return new WaitForSeconds(fireDelay);
		}
		isFiring = false;
	}

	public void TakeDamage(float damage)
	{
		currentHealth -= damage;
		if (healthBar != null)
		{
			healthBar.value = currentHealth;
		}
		if (currentHealth <= 0f)
		{
			Die();
		}
	}

	private void Die()
	{
		Object.Destroy(Object.Instantiate(DeathExplosionEffect, base.transform.position, Quaternion.identity), 2f);
		base.gameObject.transform.position = new Vector3(0f, -9999f, 0f);
		Object.Destroy(base.gameObject);
	}

	private void OnTriggerEnter(Collider other)
	{
		if (other.CompareTag("BasicBullet") && !collidersAppliedDamage.Contains(other))
		{
			TakeDamage(15f);
			collidersAppliedDamage.Add(other);
			Object.Destroy(other.gameObject);
		}
		else if (other.CompareTag("Explosion") && !collidersAppliedDamage.Contains(other))
		{
			TakeDamage(30f);
			collidersAppliedDamage.Add(other);
		}
	}
}
