using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class PlayerManager : MonoBehaviour
{
	public static PlayerManager instance;

	public List<GameObject> playersList = new List<GameObject>();

	[SerializeField]
	private GameObject PressAnyButtonUI;

	[SerializeField]
	private Material player1Material;

	[SerializeField]
	private Material player2Material;

	[SerializeField]
	private Material player1CoreMaterial;

	[SerializeField]
	private Material player2CoreMaterial;

	[Header("Healing UI")]
	private Image Player1HeatlhBar;

	private void Awake()
	{
		if (instance != null && instance != this)
		{
			Object.Destroy(base.gameObject);
		}
		else
		{
			instance = this;
		}
	}

	private void Start()
	{
		PressAnyButtonUI?.SetActive(value: true);
		if (SceneManager.GetActiveScene().buildIndex == 0)
		{
			Object.DontDestroyOnLoad(base.gameObject);
		}
	}

	public void RegisterPlayer(GameObject player)
	{
		if (!playersList.Contains(player))
		{
			playersList.Add(player);
			SetupPlayer(player);
		}
	}

	private void SetupPlayer(GameObject player)
	{
		int num = playersList.IndexOf(player);
		PlayerControls component = player.GetComponent<PlayerControls>();
		component.playerID = num + 1;
		Renderer[] componentsInChildren = player.GetComponentsInChildren<Renderer>();
		if (component.playerID == 1)
		{
			Renderer[] array = componentsInChildren;
			foreach (Renderer renderer in array)
			{
				if (renderer.gameObject.CompareTag("PlayerBody"))
				{
					renderer.material = ((component.playerID == 1) ? player1Material : player2Material);
				}
				if (renderer.gameObject.CompareTag("PlayerCore"))
				{
					renderer.material = ((component.playerID == 1) ? player1CoreMaterial : player2CoreMaterial);
				}
			}
		}
		else if (component.playerID == 2)
		{
			Renderer[] array = componentsInChildren;
			foreach (Renderer renderer2 in array)
			{
				if (renderer2.gameObject.CompareTag("PlayerBody"))
				{
					renderer2.material = ((component.playerID == 1) ? player1Material : player2Material);
				}
				if (renderer2.gameObject.CompareTag("PlayerCore"))
				{
					renderer2.material = ((component.playerID == 1) ? player1CoreMaterial : player2CoreMaterial);
				}
			}
		}
		component.UpdateAmmoUI();
	}
}
