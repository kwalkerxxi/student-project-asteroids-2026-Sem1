using System.Collections;
using kyron;
using UnityEngine;
using UnityEngine.InputSystem;

public class HealingAbility : MonoBehaviour
{
	private HealthPlayer HealthScript;

	private UIControls hud;

	[Header("Healing Circle")]
	public GameObject HealingCircle;

	[SerializeField]
	private float healAmount = 5f;

	[SerializeField]
	private float HealingDuratio = 10f;

	[SerializeField]
	private float ParticleDuration = 22f;

	[SerializeField]
	private float HealingCooldown = 30f;

	private Coroutine healingCoroutine;

	private float spawnHeightParticle = 0.5f;

	private float CooldownUITimer;

	private bool CanHealInCollider;

	private bool canSpawnHealingCircle = true;

	private bool isPaused;

	private void OnEnable()
	{
		EscKeyToPause.OnPause.AddListener(TogglePauseState);
		EscKeyToPause.OnResume.AddListener(TogglePauseState);
	}

	private void OnDisable()
	{
		EscKeyToPause.OnPause.RemoveListener(TogglePauseState);
		EscKeyToPause.OnResume.RemoveListener(TogglePauseState);
	}

	private void TogglePauseState()
	{
		isPaused = !isPaused;
	}

	private void Start()
	{
		HealthScript = GetComponent<HealthPlayer>();
		hud = GetComponentInChildren<UIControls>();
		CooldownUITimer = 0f;
		hud?.UpdateHealingCooldown(0f, HealingCooldown + ParticleDuration);
	}

	private void Update()
	{
		if (!canSpawnHealingCircle)
		{
			ApplyCooldownUI();
		}
	}

	public void HealingCircleAbility(InputAction.CallbackContext context)
	{
		if (!isPaused && context.performed)
		{
			SpawnHealingCircle();
		}
	}

	private void SpawnHealingCircle()
	{
		if (canSpawnHealingCircle)
		{
			canSpawnHealingCircle = false;
			CooldownUITimer = HealingCooldown + ParticleDuration;
			Vector3 position = base.transform.position + new Vector3(0f, spawnHeightParticle, 0f);
			Object.Destroy(Object.Instantiate(HealingCircle, position, Quaternion.identity), ParticleDuration);
			CanHealInCollider = true;
			StartCoroutine(HealingCircleCooldown());
			StartCoroutine(StopHealingAfterDuration());
		}
	}

	private void ApplyCooldownUI()
	{
		CooldownUITimer -= Time.deltaTime;
		hud?.UpdateHealingCooldown(CooldownUITimer, HealingCooldown + ParticleDuration);
	}

	private IEnumerator HealingCircleCooldown()
	{
		yield return new WaitForSeconds(ParticleDuration + HealingCooldown);
		canSpawnHealingCircle = true;
		hud?.UpdateHealingCooldown(0f, HealingCooldown + ParticleDuration);
	}

	private IEnumerator StopHealingAfterDuration()
	{
		yield return new WaitForSeconds(HealingDuratio);
		CanHealInCollider = false;
		if (healingCoroutine != null)
		{
			StopCoroutine(healingCoroutine);
			healingCoroutine = null;
		}
	}

	private IEnumerator HealingOverTime()
	{
		while (CanHealInCollider)
		{
			if (HealthScript.currentHealth < HealthScript.maxHealth)
			{
				HealthScript.currentHealth += healAmount * Time.deltaTime;
				HealthScript.currentHealth = Mathf.Min(HealthScript.currentHealth, HealthScript.maxHealth);
				hud?.UpdateHealth(HealthScript.currentHealth, HealthScript.maxHealth);
			}
			yield return null;
		}
	}

	private void OnTriggerEnter(Collider other)
	{
		if (other.CompareTag("HealingCircle") && healingCoroutine == null)
		{
			healingCoroutine = StartCoroutine(HealingOverTime());
		}
	}

	private void OnTriggerExit(Collider other)
	{
		if (other.CompareTag("HealingCircle") && healingCoroutine != null)
		{
			StopCoroutine(healingCoroutine);
			healingCoroutine = null;
		}
	}

	public void UpdatingHealthUI()
	{
		hud?.UpdateHealth(HealthScript.currentHealth, HealthScript.maxHealth);
	}
}
