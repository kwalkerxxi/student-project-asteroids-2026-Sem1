using System.Collections;
using kyron;
using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerControls : MonoBehaviour
{
	[Header("Movement System")]
	[SerializeField]
	public float moveSpeed = 10f;

	private Vector2 moveDirection;

	private Vector2 aimDirection;

	private Vector3 rotationTargetMouse;

	[SerializeField]
	private float rotationSpeed = 720f;

	private CharacterController controller;

	private Vector3 velocity;

	private float gravity = -9.81f;

	private bool isGrounded;

	[SerializeField]
	private LayerMask aimLayerMask;

	[Header("Dash System")]
	public float dashDuration = 0.2f;

	public float dashSpeed = 25f;

	public float dashCooldown = 2f;

	private bool isDashing;

	private bool canDash = true;

	[Header("Attack System")]
	public GameObject basicBullet;

	public GameObject specialBullet;

	public Transform firePoint;

	public float bulletSpeed = 10f;

	public float fireRate = 0.2f;

	private bool isShooting;

	private bool canShootSpecial = true;

	private float lastShotTime;

	[Header("Interaction System")]
	public bool canCharge;

	public int currentSpecialBullet = 4;

	public int MaxSpecialBullet = 10;

	private UIControls hud;

	[Header("Player Info")]
	public int playerID = 1;

	[Header("Particles")]
	public GameObject ShootingParticle;

	public GameObject SpecialShootingParticle;

	private bool isPaused;

	private bool isUsingMouse;

	[SerializeField]
	private GolemAnimHandler animHandler;

	private void Start()
	{
		controller = GetComponent<CharacterController>();
		hud = GetComponentInChildren<UIControls>();
		if (PlayerManager.instance != null)
		{
			PlayerManager.instance.RegisterPlayer(base.gameObject);
		}
		else
		{
			Debug.LogError("PlayerManager instance is missing from the scene!");
		}
		UpdateAmmoUI();
	}

	private void OnEnable()
	{
		EscKeyToPause.OnPause.AddListener(TogglePauseState);
		EscKeyToPause.OnResume.AddListener(TogglePauseState);
	}

	private void OnDisable()
	{
		EscKeyToPause.OnPause.RemoveListener(TogglePauseState);
		EscKeyToPause.OnResume.RemoveListener(TogglePauseState);
	}

	private void TogglePauseState()
	{
		isPaused = !isPaused;
	}

	private void Update()
	{
		if (isPaused)
		{
			return;
		}
		isGrounded = controller.isGrounded;
		if (isGrounded && velocity.y < 0f)
		{
			velocity.y = -2f;
		}
		if (isPaused)
		{
			return;
		}
		Vector3 vector = new Vector3(moveDirection.x, 0f, moveDirection.y);
		if (!isDashing)
		{
			controller.Move(vector * moveSpeed * Time.deltaTime);
		}
		Vector3 vector2 = base.transform.InverseTransformDirection(new Vector3(vector.x, 0f, vector.z));
		animHandler.SetLeftRight(vector2.x);
		animHandler.SetForwardBack(vector2.z);
		velocity.y += gravity * Time.deltaTime;
		controller.Move(velocity * Time.deltaTime);
		if (isUsingMouse)
		{
			if (Physics.Raycast(Camera.main.ScreenPointToRay(aimDirection), out var hitInfo, 100f, aimLayerMask))
			{
				rotationTargetMouse = hitInfo.point;
			}
			Vector3 vector3 = rotationTargetMouse - base.transform.position;
			vector3.y = 0f;
			if (vector3 != Vector3.zero)
			{
				Quaternion b = Quaternion.LookRotation(vector3);
				base.transform.rotation = Quaternion.Slerp(base.transform.rotation, b, 15f * Time.deltaTime);
			}
		}
		else if (aimDirection.sqrMagnitude > 0.01f)
		{
			Quaternion to = Quaternion.LookRotation(new Vector3(aimDirection.x, 0f, aimDirection.y));
			base.transform.rotation = Quaternion.RotateTowards(base.transform.rotation, to, rotationSpeed * Time.deltaTime);
		}
	}

	public void OnMove(InputAction.CallbackContext context)
	{
		moveDirection = context.ReadValue<Vector2>();
	}

	public void OnAim(InputAction.CallbackContext context)
	{
		if (!isPaused)
		{
			isUsingMouse = context.action.activeControl.ToString().ToLower().Contains("mouse");
			aimDirection = context.ReadValue<Vector2>();
		}
	}

	public void BasicAttack(InputAction.CallbackContext context)
	{
		if (!isPaused)
		{
			if (context.performed)
			{
				isShooting = true;
				StartCoroutine(KeepFiring());
			}
			else if (context.canceled)
			{
				isShooting = false;
			}
		}
	}

	public void SpecialAttack(InputAction.CallbackContext context)
	{
		if (!isPaused && context.performed)
		{
			SpecialShoot(specialBullet);
		}
	}

	public void Interact(InputAction.CallbackContext context)
	{
		if (!isPaused && context.performed)
		{
			IsCharging(40);
		}
	}

	private void BasicShoot(GameObject bulletPrefab)
	{
		Object.Instantiate(bulletPrefab, firePoint.position, firePoint.rotation);
		Quaternion rotation = Quaternion.LookRotation(firePoint.forward) * Quaternion.Euler(90f, 0f, 0f);
		Object.Destroy(Object.Instantiate(ShootingParticle, firePoint.position, rotation), 2f);
		animHandler.TriggerFire();
	}

	private void SpecialShoot(GameObject bulletPrefab)
	{
		if (canShootSpecial && currentSpecialBullet > 0)
		{
			Object.Instantiate(bulletPrefab, firePoint.position, firePoint.rotation);
			currentSpecialBullet--;
			UpdateAmmoUI();
			Quaternion rotation = Quaternion.LookRotation(firePoint.forward) * Quaternion.Euler(90f, 0f, 0f);
			Object.Destroy(Object.Instantiate(SpecialShootingParticle, firePoint.position, rotation), 2f);
			StartCoroutine(SpecialAttackCooldown());
			animHandler.TriggerFire();
		}
	}

	private IEnumerator SpecialAttackCooldown()
	{
		canShootSpecial = false;
		yield return new WaitForSeconds(1f);
		canShootSpecial = true;
	}

	private IEnumerator KeepFiring()
	{
		while (isShooting)
		{
			if (Time.time >= lastShotTime + fireRate)
			{
				BasicShoot(basicBullet);
				lastShotTime = Time.time;
			}
			yield return null;
		}
	}

	private void IsCharging(int amount)
	{
		if (canCharge)
		{
			currentSpecialBullet = Mathf.Min(currentSpecialBullet + amount, MaxSpecialBullet);
			UpdateAmmoUI();
		}
	}

	public void UpdateAmmoUI()
	{
		if (hud != null)
		{
			hud.UpdateAmmo(currentSpecialBullet, MaxSpecialBullet);
		}
	}

	private void OnTriggerEnter(Collider other)
	{
		if (other.CompareTag("AmmoStation"))
		{
			canCharge = true;
		}
	}

	private void OnTriggerExit(Collider other)
	{
		if (other.CompareTag("AmmoStation"))
		{
			canCharge = false;
		}
	}
}
