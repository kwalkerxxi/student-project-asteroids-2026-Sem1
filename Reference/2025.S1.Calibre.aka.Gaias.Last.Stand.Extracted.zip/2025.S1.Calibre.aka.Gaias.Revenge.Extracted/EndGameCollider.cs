using UnityEngine;
using UnityEngine.SceneManagement;

public class EndGameCollider : MonoBehaviour
{
	private void OnTriggerEnter(Collider other)
	{
		if (other.CompareTag("Player1"))
		{
			SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
			PlayerManager.instance.playersList.Clear();
		}
	}
}
