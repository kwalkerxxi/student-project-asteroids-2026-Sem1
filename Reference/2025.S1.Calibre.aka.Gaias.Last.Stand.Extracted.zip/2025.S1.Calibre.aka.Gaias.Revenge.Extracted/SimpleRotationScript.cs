using UnityEngine;

public class SimpleRotationScript : MonoBehaviour
{
	[Header("Rotation Speed (degrees per second)")]
	public float rotationSpeedX = 100f;

	public float rotationSpeedZ = 100f;

	private Rigidbody rb;

	private void Awake()
	{
		rb = GetComponent<Rigidbody>();
		rb.useGravity = false;
		rb.isKinematic = true;
	}

	private void Update()
	{
		float xAngle = rotationSpeedX * Time.deltaTime;
		float zAngle = rotationSpeedZ * Time.deltaTime;
		base.transform.Rotate(xAngle, 0f, zAngle);
	}
}
