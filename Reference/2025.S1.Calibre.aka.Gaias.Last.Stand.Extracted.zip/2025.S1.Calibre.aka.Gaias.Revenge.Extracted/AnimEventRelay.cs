using UnityEngine;

public class AnimEventRelay : MonoBehaviour
{
	public HealthPlayer healthPlayer;

	public void Explode()
	{
		healthPlayer.ExplodeIntoRocks();
	}
}
