using UnityEngine;

public class BossGroundPainter : MonoBehaviour
{
	[Header("Grass (Detail) settings")]
	public int detailLayerIndex;

	public float grassRadius = 5f;

	[Header("Texture (Splat) settings")]
	public int splatLayerIndex = 1;

	public float paintRadius = 5f;

	public float paintStrength = 1f;

	private Terrain terrain;

	private TerrainData terrainData;

	private int detailWidth;

	private int detailHeight;

	private int[,] originalDetails;

	private float[,,] originalAlphamaps;

	private void Start()
	{
		terrain = Terrain.activeTerrain;
		if (terrain == null)
		{
			Debug.LogError("No active terrain found!");
			return;
		}
		terrainData = terrain.terrainData;
		detailWidth = terrainData.detailWidth;
		detailHeight = terrainData.detailHeight;
		originalDetails = terrainData.GetDetailLayer(0, 0, detailWidth, detailHeight, detailLayerIndex);
		originalAlphamaps = terrainData.GetAlphamaps(0, 0, terrainData.alphamapWidth, terrainData.alphamapHeight);
		RemoveGrassArea();
		PaintTextureArea();
	}

	private void RemoveGrassArea()
	{
		Vector3 position = terrain.transform.position;
		Vector3 vector = base.transform.position - position;
		int num = Mathf.RoundToInt(vector.x / terrainData.size.x * (float)detailWidth);
		int num2 = Mathf.RoundToInt(vector.z / terrainData.size.z * (float)detailHeight);
		int num3 = Mathf.RoundToInt(grassRadius / terrainData.size.x * (float)detailWidth);
		int num4 = Mathf.Clamp(num - num3, 0, detailWidth - 1);
		int num5 = Mathf.Clamp(num + num3, 0, detailWidth - 1);
		int num6 = Mathf.Clamp(num2 - num3, 0, detailHeight - 1);
		int num7 = Mathf.Clamp(num2 + num3, 0, detailHeight - 1);
		int num8 = num5 - num4 + 1;
		int num9 = num7 - num6 + 1;
		int[,] array = new int[num9, num8];
		for (int i = 0; i < num9; i++)
		{
			for (int j = 0; j < num8; j++)
			{
				array[i, j] = originalDetails[i + num6, j + num4];
			}
		}
		for (int k = 0; k < num9; k++)
		{
			for (int l = 0; l < num8; l++)
			{
				int num10 = l + num4 - num;
				int num11 = k + num6 - num2;
				if (Mathf.Sqrt(num10 * num10 + num11 * num11) <= (float)num3)
				{
					array[k, l] = 0;
				}
			}
		}
		terrainData.SetDetailLayer(num4, num6, detailLayerIndex, array);
	}

	private void PaintTextureArea()
	{
		Vector3 position = terrain.transform.position;
		Vector3 vector = base.transform.position - position;
		int num = Mathf.RoundToInt(vector.x / terrainData.size.x * (float)terrainData.alphamapWidth);
		int num2 = Mathf.RoundToInt(vector.z / terrainData.size.z * (float)terrainData.alphamapHeight);
		int num3 = Mathf.RoundToInt(paintRadius / terrainData.size.x * (float)terrainData.alphamapWidth);
		int num4 = Mathf.Clamp(num - num3, 0, terrainData.alphamapWidth - 1);
		int num5 = Mathf.Clamp(num + num3, 0, terrainData.alphamapWidth - 1);
		int num6 = Mathf.Clamp(num2 - num3, 0, terrainData.alphamapHeight - 1);
		int num7 = Mathf.Clamp(num2 + num3, 0, terrainData.alphamapHeight - 1);
		int num8 = num5 - num4 + 1;
		int num9 = num7 - num6 + 1;
		float[,,] alphamaps = terrainData.GetAlphamaps(num4, num6, num8, num9);
		for (int i = 0; i < num9; i++)
		{
			for (int j = 0; j < num8; j++)
			{
				int num10 = j + num4 - num;
				int num11 = i + num6 - num2;
				float num12 = Mathf.Sqrt(num10 * num10 + num11 * num11);
				if (!(num12 <= (float)num3))
				{
					continue;
				}
				float num13 = paintStrength * (1f - num12 / (float)num3);
				alphamaps[i, j, splatLayerIndex] = Mathf.Clamp01(alphamaps[i, j, splatLayerIndex] + num13);
				float num14 = 0f;
				for (int k = 0; k < terrainData.alphamapLayers; k++)
				{
					if (k != splatLayerIndex)
					{
						num14 += alphamaps[i, j, k];
					}
				}
				if (!(num14 > 0f))
				{
					continue;
				}
				float num15 = (1f - alphamaps[i, j, splatLayerIndex]) / num14;
				for (int l = 0; l < terrainData.alphamapLayers; l++)
				{
					if (l != splatLayerIndex)
					{
						alphamaps[i, j, l] *= num15;
					}
				}
			}
		}
		terrainData.SetAlphamaps(num4, num6, alphamaps);
	}

	private void OnDisable()
	{
		if (terrainData != null && originalDetails != null)
		{
			terrainData.SetDetailLayer(0, 0, detailLayerIndex, originalDetails);
		}
		if (terrainData != null && originalAlphamaps != null)
		{
			terrainData.SetAlphamaps(0, 0, originalAlphamaps);
		}
	}

	private void OnDestroy()
	{
		OnDisable();
	}
}
