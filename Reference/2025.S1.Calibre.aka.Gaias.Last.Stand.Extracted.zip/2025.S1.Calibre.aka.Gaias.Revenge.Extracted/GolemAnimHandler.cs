using UnityEngine;

public class GolemAnimHandler : MonoBehaviour
{
	[SerializeField]
	private Animator animator;

	public void SetLeftRight(float value)
	{
		animator.SetFloat("LeftRight", value, 0.1f, Time.deltaTime);
	}

	public void SetForwardBack(float value)
	{
		animator.SetFloat("ForwardBack", value, 0.1f, Time.deltaTime);
	}

	public void SetIsAiming(bool isAiming)
	{
		animator.SetBool("isAiming", isAiming);
	}

	public void SetIsDashing(bool isDashing)
	{
		animator.SetBool("isDashing", isDashing);
	}

	public void SetIsChargingCannon(bool isCharging)
	{
		animator.SetBool("isChargingCannon", isCharging);
	}

	public void TriggerFire()
	{
		animator.SetTrigger("Fire");
	}

	public void TriggerHit()
	{
		animator.SetTrigger("TakeDamage");
	}

	public void SetIsDead(bool dead)
	{
		animator.SetBool("isDead", dead);
	}

	public void UpdateTurnAnimation(float rotationDelta)
	{
		float num = 0.1f;
		float num2 = 0f;
		num2 = ((rotationDelta > num) ? 1f : ((!(rotationDelta < 0f - num)) ? 0f : (-1f)));
		animator.SetFloat("LeftRight", num2, 0.1f, Time.deltaTime);
	}
}
