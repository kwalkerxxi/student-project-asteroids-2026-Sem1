using UnityEngine;

public class RocketScript : MonoBehaviour
{
	[SerializeField]
	private float rocketSpeed = 5f;

	[SerializeField]
	private int dmg = 20;

	[SerializeField]
	private float lifeTime = 2f;

	[SerializeField]
	private float rotationSpeed = 1f;

	[SerializeField]
	private float detectRange = 1f;

	[SerializeField]
	private LayerMask playerLayer = -1;

	[SerializeField]
	private GameObject ExplosionParticle;

	private Collider[] targetColliders;

	private Transform targetPlayer;

	private Rigidbody rocketRigidbody;

	private bool hasTarget;

	private void Start()
	{
		rocketRigidbody = GetComponent<Rigidbody>();
		rocketRigidbody.linearVelocity = base.transform.forward * rocketSpeed;
		hasTarget = false;
		Object.Destroy(base.gameObject, lifeTime);
	}

	private void FixedUpdate()
	{
		if (!hasTarget)
		{
			targetColliders = Physics.OverlapSphere(base.transform.position, detectRange, playerLayer);
			if (targetColliders.Length == 0)
			{
				return;
			}
			targetPlayer = targetColliders[0].transform;
		}
		if (targetPlayer != null)
		{
			hasTarget = true;
			Quaternion b = Quaternion.LookRotation((targetPlayer.position - base.transform.position).normalized);
			base.transform.rotation = Quaternion.Slerp(base.transform.rotation, b, rotationSpeed * Time.deltaTime);
			rocketRigidbody.linearVelocity = base.transform.forward * rocketSpeed;
		}
	}

	private void OnTriggerEnter(Collider other)
	{
		if (other.CompareTag("Player"))
		{
			if (other.TryGetComponent<HealthPlayer>(out var component))
			{
				component.TakeDamage(dmg);
			}
			Object.Destroy(base.gameObject);
		}
	}

	private void OnDestroy()
	{
		Object.Instantiate(ExplosionParticle, base.transform.position, base.transform.rotation, null);
	}
}
