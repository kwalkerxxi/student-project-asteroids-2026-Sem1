using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.LowLevel;
using UnityEngine.InputSystem.Users;

public class GamePadCursor : MonoBehaviour
{
	[SerializeField]
	private PlayerInput playerInput;

	[SerializeField]
	private RectTransform cursorTransform;

	[SerializeField]
	private float cursorSpeed = 1000f;

	[SerializeField]
	private RectTransform canvasRectTransform;

	[SerializeField]
	private Canvas canvas;

	[SerializeField]
	private float padding = 50f;

	private bool preivousMouseState;

	private Mouse virtualMouse;

	private Mouse currentMouse;

	private Camera mainCamera;

	private string previousControlScheme = "";

	private const string gamepadScheme = "Gamepad";

	private const string mouseScheme = "Keyboard&Mouse";

	private void OnEnable()
	{
		mainCamera = Camera.main;
		currentMouse = Mouse.current;
		if (virtualMouse == null)
		{
			virtualMouse = (Mouse)InputSystem.AddDevice("VirtualMouse");
		}
		else if (!virtualMouse.added)
		{
			InputSystem.AddDevice(virtualMouse);
		}
		InputUser.PerformPairingWithDevice(virtualMouse, playerInput.user);
		if (cursorTransform != null)
		{
			Vector2 anchoredPosition = cursorTransform.anchoredPosition;
			InputState.Change(virtualMouse.position, anchoredPosition);
		}
		InputSystem.onAfterUpdate += UpdateMotion;
		playerInput.onControlsChanged += OnControlsChanged;
	}

	private void OnDisable()
	{
		if (virtualMouse != null && virtualMouse.added)
		{
			InputSystem.RemoveDevice(virtualMouse);
		}
		InputSystem.onAfterUpdate -= UpdateMotion;
		playerInput.onControlsChanged -= OnControlsChanged;
	}

	private void UpdateMotion()
	{
		if (virtualMouse != null && Gamepad.current != null)
		{
			Vector2 vector = Gamepad.current.leftStick.ReadValue();
			vector *= cursorSpeed * Time.deltaTime;
			Vector2 vector2 = virtualMouse.position.ReadValue();
			Vector2 vector3 = vector;
			Vector2 vector4 = vector2 + vector3;
			vector4.x = Mathf.Clamp(vector4.x, padding, (float)Screen.width - padding);
			vector4.y = Mathf.Clamp(vector4.y, padding, (float)Screen.height - padding);
			InputState.Change(virtualMouse.position, vector4);
			InputState.Change(virtualMouse.delta, vector3);
			bool flag = Gamepad.current.aButton.IsPressed();
			if (preivousMouseState != flag)
			{
				virtualMouse.CopyState<MouseState>(out var state);
				state.WithButton(MouseButton.Left, flag);
				InputState.Change(virtualMouse, state);
				preivousMouseState = flag;
			}
			AnchorCursor(vector4);
		}
	}

	private void AnchorCursor(Vector2 position)
	{
		RectTransformUtility.ScreenPointToLocalPointInRectangle(canvasRectTransform, position, (canvas.renderMode == RenderMode.ScreenSpaceOverlay) ? null : mainCamera, out var localPoint);
		cursorTransform.anchoredPosition = localPoint;
	}

	private void OnControlsChanged(PlayerInput input)
	{
		if (playerInput.currentControlScheme == "Keyboard&Mouse" && previousControlScheme != "Keyboard&Mouse")
		{
			cursorTransform.gameObject.SetActive(value: false);
			Cursor.visible = true;
			currentMouse.WarpCursorPosition(virtualMouse.position.ReadValue());
			previousControlScheme = "Keyboard&Mouse";
		}
		else if (playerInput.currentControlScheme == "Gamepad" && previousControlScheme != "Gamepad")
		{
			cursorTransform.gameObject.SetActive(value: true);
			Cursor.visible = false;
			InputState.Change(virtualMouse.position, currentMouse.position.ReadValue());
			AnchorCursor(currentMouse.position.ReadValue());
			previousControlScheme = "Gamepad";
		}
	}
}
