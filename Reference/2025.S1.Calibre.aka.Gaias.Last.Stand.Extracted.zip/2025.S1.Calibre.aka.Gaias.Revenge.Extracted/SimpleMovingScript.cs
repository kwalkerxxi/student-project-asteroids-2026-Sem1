using UnityEngine;

public class SimpleMovingScript : MonoBehaviour
{
	public enum Direction
	{
		Up,
		Down,
		Forward,
		Backward,
		Right,
		Left
	}

	public float distance = 1f;

	public float speed = 1f;

	public Direction moveDirection;

	private Vector3 startPos;

	private Vector3 targetA;

	private Vector3 targetB;

	private Vector3 currentTarget;

	private void Start()
	{
		startPos = base.transform.localPosition;
		Vector3 directionVector = GetDirectionVector();
		targetA = startPos + directionVector * distance;
		targetB = startPos - directionVector * distance;
		currentTarget = targetB;
	}

	private void Update()
	{
		base.transform.localPosition = Vector3.MoveTowards(base.transform.localPosition, currentTarget, speed * Time.deltaTime);
		if (Vector3.Distance(base.transform.localPosition, currentTarget) < 0.01f)
		{
			currentTarget = ((currentTarget == targetA) ? targetB : targetA);
		}
	}

	private Vector3 GetDirectionVector()
	{
		return moveDirection switch
		{
			Direction.Up => base.transform.up, 
			Direction.Down => -base.transform.up, 
			Direction.Forward => base.transform.forward, 
			Direction.Backward => -base.transform.forward, 
			Direction.Right => base.transform.right, 
			Direction.Left => -base.transform.right, 
			_ => base.transform.up, 
		};
	}
}
