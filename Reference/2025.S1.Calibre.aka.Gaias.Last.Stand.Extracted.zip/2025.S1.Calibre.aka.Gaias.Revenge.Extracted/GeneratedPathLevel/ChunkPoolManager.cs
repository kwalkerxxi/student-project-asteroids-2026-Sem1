using UnityEngine;
using UnityEngine.Pool;

namespace GeneratedPathLevel;

public class ChunkPoolManager : MonoBehaviour
{
	public enum ChunkType
	{
		Start,
		End,
		Straight,
		TurnLeft,
		TurnRight
	}

	[SerializeField]
	private GameObject startPrefab;

	[SerializeField]
	private GameObject endPrefab;

	[SerializeField]
	private GameObject straightPrefab;

	[SerializeField]
	private GameObject turnLeftPrefab;

	[SerializeField]
	private GameObject turnRightPrefab;

	private ObjectPool<GameObject> straightPool;

	private ObjectPool<GameObject> turnLeftPool;

	private ObjectPool<GameObject> turnRightPool;

	private void Awake()
	{
		straightPool = CreatePool(straightPrefab);
		turnLeftPool = CreatePool(turnLeftPrefab);
		turnRightPool = CreatePool(turnRightPrefab);
	}

	private ObjectPool<GameObject> CreatePool(GameObject prefab)
	{
		return new ObjectPool<GameObject>(() => Object.Instantiate(prefab), delegate(GameObject gameObjectAddedToPool)
		{
			gameObjectAddedToPool.SetActive(value: true);
		}, delegate(GameObject gameObjectAddedToPool)
		{
			gameObjectAddedToPool.SetActive(value: false);
		}, delegate(GameObject gameObjectAddedToPool)
		{
			Object.Destroy(gameObjectAddedToPool);
		}, collectionCheck: false, 10, 50);
	}

	public GameObject GetChunk(ChunkType chunkTypeToUse, Vector3 position, Quaternion rotation, Transform holder)
	{
		GameObject gameObject = null;
		gameObject = chunkTypeToUse switch
		{
			ChunkType.Start => Object.Instantiate(startPrefab), 
			ChunkType.End => Object.Instantiate(endPrefab), 
			ChunkType.Straight => straightPool.Get(), 
			ChunkType.TurnRight => turnRightPool.Get(), 
			_ => turnLeftPool.Get(), 
		};
		gameObject.transform.position = position;
		gameObject.transform.rotation = rotation;
		gameObject.transform.SetParent(holder);
		return gameObject;
	}

	public void ReleaseChunk(GameObject chunk)
	{
		if (chunk.name.Contains("Straight"))
		{
			straightPool.Release(chunk);
		}
		else if (chunk.name.Contains("Right"))
		{
			turnRightPool.Release(chunk);
		}
		else if (chunk.name.Contains("Left"))
		{
			turnLeftPool.Release(chunk);
		}
		else
		{
			Object.Destroy(chunk);
		}
	}
}
