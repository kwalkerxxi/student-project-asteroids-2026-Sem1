using System;
using System.Collections.Generic;
using UnityEngine;

namespace GeneratedPathLevel;

[Serializable]
public struct PathData
{
	public List<Vector2Int> pathPoints;
}
