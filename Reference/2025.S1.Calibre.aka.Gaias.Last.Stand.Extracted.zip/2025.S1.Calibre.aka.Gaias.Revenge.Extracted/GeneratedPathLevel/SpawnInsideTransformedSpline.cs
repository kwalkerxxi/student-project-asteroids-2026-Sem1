using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Splines;

namespace GeneratedPathLevel;

public class SpawnInsideTransformedSpline : MonoBehaviour
{
	[Header("Required items for Instancing")]
	public SplineContainer splineContainerToUseAsPolygon;

	public GameObject itemToSpawn;

	public float yHeight;

	public int instanceCount = 10;

	[Header("GPU Instancing")]
	public bool useGPUModel;

	public Mesh gpuMesh;

	public Material gpuMaterial;

	private List<Matrix4x4> instanceMatrices = new List<Matrix4x4>();

	private RenderParams gpuRenderParameters;

	private void Start()
	{
		if (splineContainerToUseAsPolygon == null)
		{
			splineContainerToUseAsPolygon = GetComponent<SplineContainer>();
		}
		if (splineContainerToUseAsPolygon == null)
		{
			Debug.LogError("Need to assign the SplineContainer for the " + base.name + " attaached to " + base.gameObject.name);
		}
		if (useGPUModel)
		{
			gpuRenderParameters = new RenderParams(gpuMaterial);
			gpuRenderParameters.receiveShadows = true;
			gpuRenderParameters.shadowCastingMode = ShadowCastingMode.On;
			SpawnInstancesGPU();
		}
		else
		{
			SpawnInstancesPrefab();
		}
	}

	private void SpawnInstancesPrefab()
	{
		for (int i = 0; i < instanceCount; i++)
		{
			Vector2 randomPointInsidePolygon = GetRandomPointInsidePolygon();
			Object.Instantiate(position: new Vector3(randomPointInsidePolygon.x, yHeight, randomPointInsidePolygon.y), original: itemToSpawn, rotation: Quaternion.identity);
		}
	}

	private void SpawnInstancesGPU()
	{
		instanceMatrices.Clear();
		for (int i = 0; i < instanceCount; i++)
		{
			Vector2 randomPointInsidePolygon = GetRandomPointInsidePolygon();
			Vector3 pos = new Vector3(randomPointInsidePolygon.x, yHeight, randomPointInsidePolygon.y);
			Quaternion identity = Quaternion.identity;
			identity = Quaternion.Euler(new Vector3(0f, Random.Range(0, 360), 0f));
			Matrix4x4 item = Matrix4x4.TRS(pos, identity, Vector3.one);
			instanceMatrices.Add(item);
		}
	}

	private void Update()
	{
		if (useGPUModel && instanceMatrices.Count > 0)
		{
			int num = 1023;
			for (int i = 0; i < instanceMatrices.Count; i += num)
			{
				int count = Mathf.Min(num, instanceMatrices.Count - i);
				Graphics.RenderMeshInstanced(in gpuRenderParameters, gpuMesh, 0, instanceMatrices.GetRange(i, count));
			}
		}
	}

	private Vector2 GetRandomPointInsidePolygon()
	{
		List<Vector2> list = new List<Vector2>();
		Transform transform = splineContainerToUseAsPolygon.transform;
		foreach (BezierKnot knot in splineContainerToUseAsPolygon.Spline.Knots)
		{
			Vector3 position = knot.Position;
			Vector3 vector = transform.TransformPoint(position);
			list.Add(new Vector2(vector.x, vector.z));
		}
		float num = float.MaxValue;
		float num2 = float.MinValue;
		float num3 = float.MaxValue;
		float num4 = float.MinValue;
		foreach (Vector2 item in list)
		{
			if (item.x < num)
			{
				num = item.x;
			}
			if (item.x > num2)
			{
				num2 = item.x;
			}
			if (item.y < num3)
			{
				num3 = item.y;
			}
			if (item.y > num4)
			{
				num4 = item.y;
			}
		}
		for (int i = 0; i < 1000; i++)
		{
			float x = Random.Range(num, num2);
			float y = Random.Range(num3, num4);
			Vector2 vector2 = new Vector2(x, y);
			if (IsPointInPolygon(vector2, list))
			{
				return vector2;
			}
		}
		Debug.LogWarning("Could not find point inside polygon.");
		return list[0];
	}

	private bool IsPointInPolygon(Vector2 point, List<Vector2> polygon)
	{
		int count = polygon.Count;
		bool flag = false;
		int num = 0;
		int index = count - 1;
		while (num < count)
		{
			if (polygon[num].y > point.y != polygon[index].y > point.y && point.x < (polygon[index].x - polygon[num].x) * (point.y - polygon[num].y) / (polygon[index].y - polygon[num].y) + polygon[num].x)
			{
				flag = !flag;
			}
			index = num++;
		}
		return flag;
	}
}
