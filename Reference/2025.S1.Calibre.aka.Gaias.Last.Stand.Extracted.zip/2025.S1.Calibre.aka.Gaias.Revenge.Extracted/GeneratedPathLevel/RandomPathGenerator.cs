using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using UnityEngine;

namespace GeneratedPathLevel;

[RequireComponent(typeof(LineRenderer))]
public class RandomPathGenerator : MonoBehaviour
{
	[Obsolete]
	private Stopwatch stopwatch;

	[Obsolete]
	private bool isRunning = true;

	[Header("Grid Settings (Note: Do not make too small)")]
	[SerializeField]
	private int width = 10;

	[SerializeField]
	private int depth = 10;

	[Header("Path Settings (Note: Do not make too short or long)")]
	[SerializeField]
	private Vector2Int startPoint = new Vector2Int(0, 0);

	[SerializeField]
	private Vector2Int endPoint = new Vector2Int(9, 9);

	[SerializeField]
	private int pathLength = 20;

	[SerializeField]
	private int maximumAttemptsToCreatePath = 5;

	[Header("Animation")]
	[SerializeField]
	private bool animatePathOverTime = true;

	[SerializeField]
	private float drawDelay = 0.05f;

	[SerializeField]
	private float lineRendererWidth = 15f;

	[SerializeField]
	private float lineRendererOffsetY = 5f;

	private List<Vector2Int> path;

	private LineRenderer lineRenderer;

	private int currentAttemptsAtCreatingLevel;

	[Header("Prefab Chunk Size")]
	[SerializeField]
	private float chunkSizeX = 50f;

	[SerializeField]
	private float chunkSizeZ = 50f;

	[Space(20f)]
	[Header("GameObjects for showing path as Arrows")]
	[SerializeField]
	private bool useArrowPrefabs;

	[Header("Prefabs for Start and End Markers")]
	[SerializeField]
	private GameObject[] startArrowPrefab;

	[SerializeField]
	private GameObject[] endArrowPrefab;

	[Header("Prefabs for Path Markers")]
	[SerializeField]
	private GameObject[] straightArrowPrefab;

	[SerializeField]
	private GameObject[] leftTurnArrowPrefab;

	[SerializeField]
	private GameObject[] rightTurnArrowPrefab;

	[Space(20f)]
	[Header("GameObjects for showing path as final design")]
	[SerializeField]
	private bool useChunkPrefabs;

	[Header("Prefabs for Start and End Chunks")]
	[SerializeField]
	private GameObject[] startChunkPrefab;

	[SerializeField]
	private GameObject[] endChunkPrefab;

	[Header("Prefabs for Path Chunks")]
	[SerializeField]
	private GameObject[] straightChunk;

	[SerializeField]
	private GameObject[] leftTurnChunk;

	[SerializeField]
	private GameObject[] rightTurnChunk;

	private GameObject levelItemHolder;

	[Header("Changes Kyron Has Made")]
	public GameObject RemoveAfterLoading;

	public GameObject RemoveAfterLoading2;

	public GameObject CanvasToReEnable;

	[Header("Kyron - SplineCreator")]
	public float spacingMultiplier = 1f;

	public float spawnHeightOffset = 20f;

	[Header("Kyron - PaintPathCreator")]
	public Terrain terrain;

	public int pathTextureLayerIndex = 1;

	public float brushSize = 5f;

	private float[,,] originalAlphamaps;

	[Range(0f, 1f)]
	public float brushOpacity = 1f;

	private static readonly Vector2Int[] directions = new Vector2Int[4]
	{
		Vector2Int.right,
		Vector2Int.left,
		Vector2Int.up,
		Vector2Int.down
	};

	private void Start()
	{
		pathLength = HoldDifficulty.DifficultyPathLength;
		lineRenderer = GetComponent<LineRenderer>();
		lineRenderer.widthMultiplier = 0.1f;
		lineRenderer.material = new Material(Shader.Find("Sprites/Default"));
		lineRenderer.startColor = Color.white;
		lineRenderer.endColor = Color.white;
		RemoveAfterLoading.SetActive(value: true);
		RemoveAfterLoading2.SetActive(value: true);
		CanvasToReEnable.SetActive(value: false);
		GenerateLevelPointsAndShowViaLineRenderer();
		if (path == null || path.Count == 0)
		{
			UnityEngine.Debug.LogWarning("Path is empty or null.");
		}
		else
		{
			PaintTerrainAlongSpline();
		}
	}

	private void OnEnable()
	{
	}

	private void OnDisable()
	{
		RestoreOriginalAlphamaps();
	}

	[Obsolete]
	private IEnumerator StopAfterTime(float duration)
	{
		yield return new WaitForSeconds(duration);
		isRunning = false;
		UnityEngine.Debug.Log("Code execution stopped.");
	}

	public void GenerateLevelPointsAndShowViaLineRenderer()
	{
		path = new List<Vector2Int>();
		if (GeneratePathData(startPoint, endPoint, pathLength, out path))
		{
			UnityEngine.Debug.Log($"<color=green>Path generated successfully. Path found with {path.Count} steps.</color>");
			currentAttemptsAtCreatingLevel = 0;
			StartCoroutine(AnimatePathDrawing(path));
			return;
		}
		currentAttemptsAtCreatingLevel++;
		if (currentAttemptsAtCreatingLevel > maximumAttemptsToCreatePath)
		{
			UnityEngine.Debug.LogWarning($"<color=red>No valid paths found. Failed to generate a path with the given constraints. Made {maximumAttemptsToCreatePath} attempts but have reached maximum.</color>");
			currentAttemptsAtCreatingLevel = 0;
		}
		else
		{
			UnityEngine.Debug.LogWarning($"<color=red>No valid path found. Failed to generate a path with the given constraints. Current attempts made {currentAttemptsAtCreatingLevel}/{maximumAttemptsToCreatePath}.</color>");
			GenerateLevelPointsAndShowViaLineRenderer();
		}
	}

	private void CreateSpawnedItemsParentHolder()
	{
		if (levelItemHolder == null)
		{
			levelItemHolder = new GameObject("Holder");
			return;
		}
		UnityEngine.Object.Destroy(levelItemHolder);
		levelItemHolder = new GameObject("Holder");
	}

	private void PlaceStartAndEndPathGameObjects(GameObject[] startLocationPrefabs, GameObject[] endLocationPrefabs)
	{
		if (path == null || path.Count < 2)
		{
			return;
		}
		Vector3 position = new Vector3((float)path[0].x * chunkSizeX, 0f, (float)path[0].y * chunkSizeZ);
		Vector2Int vector2Int = path[1] - path[0];
		if (startArrowPrefab != null)
		{
			GameObject gameObject = UnityEngine.Object.Instantiate(RandomGameObjectFromArray(startLocationPrefabs), position, Quaternion.identity, levelItemHolder.transform);
			gameObject.name = "START - " + gameObject.name;
			Vector3 vector = new Vector3(vector2Int.x, 0f, vector2Int.y);
			if (vector != Vector3.zero)
			{
				gameObject.transform.rotation = Quaternion.LookRotation(vector, Vector3.up);
			}
		}
		List<Vector2Int> list = path;
		float x = (float)list[list.Count - 1].x * chunkSizeX;
		List<Vector2Int> list2 = path;
		Vector3 position2 = new Vector3(x, 0f, (float)list2[list2.Count - 1].y * chunkSizeZ);
		List<Vector2Int> list3 = path;
		Vector2Int vector2Int2 = list3[list3.Count - 1];
		List<Vector2Int> list4 = path;
		Vector2Int vector2Int3 = vector2Int2 - list4[list4.Count - 2];
		if (endArrowPrefab != null)
		{
			GameObject gameObject2 = UnityEngine.Object.Instantiate(RandomGameObjectFromArray(endLocationPrefabs), position2, Quaternion.identity, levelItemHolder.transform);
			gameObject2.name = "END - " + gameObject2.name;
			Vector3 vector2 = new Vector3(vector2Int3.x, 0f, vector2Int3.y);
			if (vector2 != Vector3.zero)
			{
				gameObject2.transform.rotation = Quaternion.LookRotation(vector2, Vector3.up);
			}
		}
	}

	private void PlacePathGameObjects(GameObject[] straightLocationPrefabs, GameObject[] leftTurnLocationPrefabs, GameObject[] rightLocationPrefabs)
	{
		if (path == null || path.Count < 3)
		{
			return;
		}
		for (int i = 1; i < path.Count - 1; i++)
		{
			Vector2Int vector2Int = path[i - 1];
			Vector2Int vector2Int2 = path[i];
			Vector2Int vector2Int3 = path[i + 1];
			Vector2Int vector2Int4 = vector2Int2 - vector2Int;
			Vector2Int vector2Int5 = vector2Int3 - vector2Int2;
			GameObject gameObject = null;
			float yAngle = 0f;
			if (vector2Int4 == vector2Int5)
			{
				gameObject = RandomGameObjectFromArray(straightLocationPrefabs);
			}
			else
			{
				int num = vector2Int4.x * vector2Int5.y - vector2Int4.y * vector2Int5.x;
				if (num > 0)
				{
					gameObject = RandomGameObjectFromArray(leftTurnLocationPrefabs);
					yAngle = 90f;
				}
				else if (num < 0)
				{
					gameObject = RandomGameObjectFromArray(rightLocationPrefabs);
					yAngle = -90f;
				}
			}
			if (gameObject != null)
			{
				Vector3 position = new Vector3((float)vector2Int2.x * chunkSizeX, 0f, (float)vector2Int2.y * chunkSizeZ);
				GameObject gameObject2 = UnityEngine.Object.Instantiate(gameObject, position, Quaternion.identity, levelItemHolder.transform);
				gameObject2.name = $"Path Item {i} - {gameObject2.name}";
				Vector3 vector = new Vector3(vector2Int5.x, 0f, vector2Int5.y);
				if (vector != Vector3.zero)
				{
					gameObject2.transform.rotation = Quaternion.LookRotation(vector, Vector3.up);
					gameObject2.transform.Rotate(0f, yAngle, 0f, Space.Self);
				}
			}
		}
	}

	private bool GeneratePathData(Vector2Int startPoint, Vector2Int endPoint, int pathLength, out List<Vector2Int> resultPath)
	{
		HashSet<Vector2Int> visitedPoints = new HashSet<Vector2Int>();
		HashSet<(Vector2Int, int)> visitedStates = new HashSet<(Vector2Int, int)>();
		List<Vector2Int> path = new List<Vector2Int>();
		int num = (int)Mathf.Pow(3f, pathLength);
		int maximumVisits = Mathf.Clamp(num * 2, 1000, 100000);
		bool flag = DFS(startPoint, pathLength);
		resultPath = (flag ? path : null);
		return flag;
		bool DFS(Vector2Int currentPoint, int remainingLength)
		{
			if (visitedStates.Count > maximumVisits)
			{
				UnityEngine.Debug.LogWarning("Too many states visited, aborting path generation.");
				return false;
			}
			if (remainingLength < 0)
			{
				return false;
			}
			if (Mathf.Abs(currentPoint.x - endPoint.x) + Mathf.Abs(currentPoint.y - endPoint.y) > remainingLength)
			{
				return false;
			}
			if (currentPoint == endPoint)
			{
				if (remainingLength == 0)
				{
					path.Add(currentPoint);
					return true;
				}
				return false;
			}
			(Vector2Int, int) item = (currentPoint, remainingLength);
			if (visitedStates.Contains(item))
			{
				return false;
			}
			visitedStates.Add(item);
			visitedPoints.Add(currentPoint);
			path.Add(currentPoint);
			Vector2Int[] array = directions.OrderBy((Vector2Int _) => UnityEngine.Random.value).ToArray();
			foreach (Vector2Int vector2Int in array)
			{
				Vector2Int vector2Int2 = currentPoint + vector2Int;
				if (vector2Int2.x >= 0 && vector2Int2.x < width && vector2Int2.y >= 0 && vector2Int2.y < depth && !visitedPoints.Contains(vector2Int2) && DFS(vector2Int2, remainingLength - 1))
				{
					return true;
				}
			}
			path.RemoveAt(path.Count - 1);
			visitedPoints.Remove(currentPoint);
			return false;
		}
	}

	private IEnumerator AnimatePathDrawing(List<Vector2Int> pathPoints)
	{
		CreateSpawnedItemsParentHolder();
		lineRenderer.enabled = true;
		lineRenderer.positionCount = 0;
		lineRenderer.startWidth = lineRendererWidth * 0.8f;
		lineRenderer.endWidth = lineRendererWidth;
		AnimationCurve animationCurve = new AnimationCurve();
		animationCurve.AddKey(0f, lineRendererWidth * 10f);
		animationCurve.AddKey(0.25f, lineRendererWidth * 12f);
		animationCurve.AddKey(0.5f, lineRendererWidth * 10f);
		animationCurve.AddKey(0.75f, lineRendererWidth * 12f);
		animationCurve.AddKey(1f, lineRendererWidth * 10f);
		lineRenderer.widthCurve = animationCurve;
		for (int i = 0; i < pathPoints.Count; i++)
		{
			Vector3 position = new Vector3((float)pathPoints[i].x * chunkSizeX, lineRendererOffsetY, (float)pathPoints[i].y * chunkSizeZ);
			lineRenderer.positionCount = i + 1;
			lineRenderer.SetPosition(i, position);
			if (animatePathOverTime)
			{
				yield return new WaitForSeconds(drawDelay);
			}
		}
		yield return new WaitForSeconds(0.1f);
		PlaceArrowPlaceholdersOrLevelChunks();
		UnityEngine.Debug.Log("Finsihed");
		RemoveAfterLoading.SetActive(value: false);
		RemoveAfterLoading2.SetActive(value: false);
		CanvasToReEnable.SetActive(value: true);
		lineRenderer.enabled = false;
	}

	private void PlaceArrowPlaceholdersOrLevelChunks()
	{
		if (useChunkPrefabs)
		{
			PlaceStartAndEndPathGameObjects(startChunkPrefab, endChunkPrefab);
			PlacePathGameObjects(straightChunk, leftTurnChunk, rightTurnChunk);
		}
		else if (useArrowPrefabs)
		{
			PlaceStartAndEndPathGameObjects(startArrowPrefab, endArrowPrefab);
			PlacePathGameObjects(straightArrowPrefab, leftTurnArrowPrefab, rightTurnArrowPrefab);
		}
	}

	private GameObject RandomGameObjectFromArray(GameObject[] arrayToPickRandomObjectFrom)
	{
		if (arrayToPickRandomObjectFrom == null)
		{
			return new GameObject("Placeholder Chunk As Array Was Not Assigned");
		}
		if (arrayToPickRandomObjectFrom.Length == 0)
		{
			return new GameObject("Placeholder Chunk As None Was Supplied");
		}
		return arrayToPickRandomObjectFrom[UnityEngine.Random.Range(0, arrayToPickRandomObjectFrom.Length)];
	}

	private Vector3 CatmullRom(Vector3 p0, Vector3 p1, Vector3 p2, Vector3 p3, float t)
	{
		float num = t * t;
		float num2 = num * t;
		return 0.5f * (2f * p1 + (-p0 + p2) * t + (2f * p0 - 5f * p1 + 4f * p2 - p3) * num + (-p0 + 3f * p1 - 3f * p2 + p3) * num2);
	}

	private Vector3 GetPointOnSpline(List<Vector3> extendedPoints, float t)
	{
		int num = extendedPoints.Count - 3;
		float num2 = t * (float)num;
		int num3 = Mathf.Min(Mathf.FloorToInt(num2), num - 1);
		float t2 = num2 - (float)num3;
		return CatmullRom(extendedPoints[num3], extendedPoints[num3 + 1], extendedPoints[num3 + 2], extendedPoints[num3 + 3], t2);
	}

	private float GetSplineLength(List<Vector3> extendedPoints, int samples)
	{
		float num = 0f;
		Vector3 a = GetPointOnSpline(extendedPoints, 0f);
		for (int i = 1; i <= samples; i++)
		{
			float t = (float)i / (float)samples;
			Vector3 pointOnSpline = GetPointOnSpline(extendedPoints, t);
			num += Vector3.Distance(a, pointOnSpline);
			a = pointOnSpline;
		}
		return num;
	}

	private Vector3 GetDirectionOnSpline(List<Vector3> extendedPoints, float t)
	{
		float num = 0.01f;
		Vector3 pointOnSpline = GetPointOnSpline(extendedPoints, Mathf.Clamp01(t));
		return (GetPointOnSpline(extendedPoints, Mathf.Clamp01(t + num)) - pointOnSpline).normalized;
	}

	private float CalculateSplineLength(List<Vector3> extendedPoints, int samples = 50)
	{
		float num = 0f;
		Vector3 a = GetPointOnSpline(extendedPoints, 0f);
		for (int i = 1; i <= samples; i++)
		{
			float t = (float)i / (float)samples;
			Vector3 pointOnSpline = GetPointOnSpline(extendedPoints, t);
			num += Vector3.Distance(a, pointOnSpline);
			a = pointOnSpline;
		}
		return num;
	}

	private void DrawSplineGizmos(List<Vector3> pathPoints)
	{
		if (pathPoints.Count < 4)
		{
			Gizmos.color = Color.yellow;
			for (int i = 0; i < pathPoints.Count - 1; i++)
			{
				Gizmos.DrawLine(pathPoints[i] + Vector3.up * spawnHeightOffset, pathPoints[i + 1] + Vector3.up * spawnHeightOffset);
			}
			return;
		}
		List<Vector3> list = new List<Vector3>();
		list.Add(pathPoints[0]);
		list.AddRange(pathPoints);
		list.Add(pathPoints[pathPoints.Count - 1]);
		Gizmos.color = Color.yellow;
		int num = 10;
		for (int j = 0; j < list.Count - 3; j++)
		{
			for (int k = 0; k < num; k++)
			{
				float t = (float)k / (float)num;
				Vector3 vector = CatmullRom(list[j], list[j + 1], list[j + 2], list[j + 3], t);
				Gizmos.DrawLine(to: CatmullRom(list[j], list[j + 1], list[j + 2], list[j + 3], (float)(k + 1) / (float)num) + Vector3.up * spawnHeightOffset, from: vector + Vector3.up * spawnHeightOffset);
			}
		}
	}

	private void OnDrawGizmosSelected()
	{
		Gizmos.color = Color.gray;
		for (int i = 0; i <= width; i++)
		{
			Vector3 vector = new Vector3((float)i * chunkSizeX, spawnHeightOffset, 0f);
			Vector3 to = new Vector3((float)i * chunkSizeX, spawnHeightOffset, (float)depth * chunkSizeZ);
			Gizmos.DrawLine(vector, to);
		}
		for (int j = 0; j <= depth; j++)
		{
			Vector3 vector2 = new Vector3(0f, spawnHeightOffset, (float)j * chunkSizeZ);
			Vector3 to2 = new Vector3((float)width * chunkSizeX, spawnHeightOffset, (float)j * chunkSizeZ);
			Gizmos.DrawLine(vector2, to2);
		}
		if (path == null)
		{
			return;
		}
		Gizmos.color = new Color(0f, 1f, 0f, 0.3f);
		foreach (Vector2Int item2 in path)
		{
			Gizmos.DrawCube(new Vector3((float)item2.x * chunkSizeX, spawnHeightOffset, (float)item2.y * chunkSizeZ), new Vector3(chunkSizeX, 2f, chunkSizeZ) * 0.9f);
		}
		Gizmos.color = new Color(0f, 0f, 1f, 0.5f);
		Gizmos.DrawCube(new Vector3((float)startPoint.x * chunkSizeX, spawnHeightOffset, (float)startPoint.y * chunkSizeZ), new Vector3(chunkSizeX, 2f, chunkSizeZ) * 0.9f);
		Gizmos.color = new Color(1f, 0f, 0f, 0.5f);
		Gizmos.DrawCube(new Vector3((float)endPoint.x * chunkSizeX, spawnHeightOffset, (float)endPoint.y * chunkSizeZ), new Vector3(chunkSizeX, 2f, chunkSizeZ) * 0.9f);
		if (path == null || path.Count <= 0)
		{
			return;
		}
		List<Vector3> list = new List<Vector3>();
		foreach (Vector2Int item3 in path)
		{
			Vector3 item = new Vector3((float)item3.x * chunkSizeX, 0f, (float)item3.y * chunkSizeZ);
			list.Add(item);
		}
		DrawSplineGizmos(list);
	}

	public void PaintTerrainAlongSpline()
	{
		if (terrain == null || path == null || path.Count < 2)
		{
			UnityEngine.Debug.LogWarning("Missing terrain or not enough path points.");
			return;
		}
		TerrainData terrainData = terrain.terrainData;
		int alphamapWidth = terrainData.alphamapWidth;
		int alphamapHeight = terrainData.alphamapHeight;
		int alphamapLayers = terrainData.alphamapLayers;
		if (originalAlphamaps == null)
		{
			originalAlphamaps = terrainData.GetAlphamaps(0, 0, alphamapWidth, alphamapHeight);
		}
		float[,,] alphamaps = terrainData.GetAlphamaps(0, 0, alphamapWidth, alphamapHeight);
		Vector3 position = terrain.transform.position;
		int num = Mathf.RoundToInt(brushSize / terrainData.size.x * (float)alphamapWidth);
		List<Vector2Int> list = new List<Vector2Int>();
		list.Add(path[0]);
		list.AddRange(path);
		list.Add(path[path.Count - 1]);
		for (int i = 0; i < list.Count - 3; i++)
		{
			Vector3 p = new Vector3((float)list[i].x * chunkSizeX, 0f, (float)list[i].y * chunkSizeZ);
			Vector3 vector = new Vector3((float)list[i + 1].x * chunkSizeX, 0f, (float)list[i + 1].y * chunkSizeZ);
			Vector3 vector2 = new Vector3((float)list[i + 2].x * chunkSizeX, 0f, (float)list[i + 2].y * chunkSizeZ);
			Vector3 p2 = new Vector3((float)list[i + 3].x * chunkSizeX, 0f, (float)list[i + 3].y * chunkSizeZ);
			int num2 = Mathf.CeilToInt(Vector3.Distance(vector, vector2) / brushSize * 2f);
			for (int j = 0; j <= num2; j++)
			{
				float t = (float)j / (float)num2;
				Vector3 vector3 = CatmullRom(p, vector, vector2, p2, t);
				vector3.y = terrain.SampleHeight(vector3 + Vector3.up * 100f);
				Vector3 vector4 = vector3 - position;
				float num3 = vector4.x / terrainData.size.x;
				float num4 = vector4.z / terrainData.size.z;
				if (num3 < 0f || num3 > 1f || num4 < 0f || num4 > 1f)
				{
					continue;
				}
				int num5 = Mathf.RoundToInt(num3 * (float)(alphamapWidth - 1));
				int num6 = Mathf.RoundToInt(num4 * (float)(alphamapHeight - 1));
				for (int k = -num; k <= num; k++)
				{
					int num7 = num6 + k;
					if (num7 < 0 || num7 >= alphamapHeight)
					{
						continue;
					}
					for (int l = -num; l <= num; l++)
					{
						int num8 = num5 + l;
						if (num8 < 0 || num8 >= alphamapWidth)
						{
							continue;
						}
						float num9 = Mathf.Sqrt(l * l + k * k);
						if (num9 > (float)num)
						{
							continue;
						}
						float num10 = (1f - num9 / (float)num) * brushOpacity;
						float num11 = 0f;
						float[] array = new float[alphamapLayers];
						for (int m = 0; m < alphamapLayers; m++)
						{
							if (m == pathTextureLayerIndex)
							{
								array[m] = alphamaps[num7, num8, m] + num10;
							}
							else
							{
								array[m] = alphamaps[num7, num8, m] * (1f - num10);
							}
							num11 += array[m];
						}
						for (int n = 0; n < alphamapLayers; n++)
						{
							alphamaps[num7, num8, n] = array[n] / num11;
						}
					}
				}
			}
		}
		terrainData.SetAlphamaps(0, 0, alphamaps);
	}

	private void RestoreOriginalAlphamaps()
	{
		if (terrain != null && originalAlphamaps != null)
		{
			terrain.terrainData.SetAlphamaps(0, 0, originalAlphamaps);
			UnityEngine.Debug.Log("Terrain alphamaps restored.");
			originalAlphamaps = null;
		}
	}

	public List<Vector2Int> GetGeneratedPath()
	{
		return path;
	}

	public void GenerateLevelFromExisitingData(List<Vector2Int> pathPoints)
	{
		path = pathPoints;
		StartCoroutine(AnimatePathDrawing(path));
	}
}
