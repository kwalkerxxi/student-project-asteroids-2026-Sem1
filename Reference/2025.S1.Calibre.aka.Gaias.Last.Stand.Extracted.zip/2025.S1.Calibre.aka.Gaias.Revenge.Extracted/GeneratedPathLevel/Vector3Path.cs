using System;
using System.Collections.Generic;
using UnityEngine;

namespace GeneratedPathLevel;

[Serializable]
public class Vector3Path
{
	public List<Vector3> path = new List<Vector3>();
}
