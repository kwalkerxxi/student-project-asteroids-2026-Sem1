using UnityEngine;

namespace GeneratedPathLevel;

public static class VectorExtensions
{
	public static Vector2 ToXZ(this Vector3 v)
	{
		return new Vector2(v.x, v.z);
	}
}
