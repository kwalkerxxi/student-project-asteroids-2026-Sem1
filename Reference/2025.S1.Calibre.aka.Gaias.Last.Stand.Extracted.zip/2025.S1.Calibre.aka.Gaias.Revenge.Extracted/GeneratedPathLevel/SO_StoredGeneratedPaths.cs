using System.Collections.Generic;
using UnityEngine;

namespace GeneratedPathLevel;

[CreateAssetMenu(fileName = "StoredPathData", menuName = "ScriptableObjects/StoredPathData")]
public class SO_StoredGeneratedPaths : ScriptableObject
{
	[SerializeField]
	private List<PathData> storedPaths = new List<PathData>();

	public int TotalPathsCount => storedPaths.Count;

	public void AddPath(PathData newPath)
	{
		storedPaths.Add(newPath);
	}

	public List<PathData> GetAllPaths()
	{
		return storedPaths;
	}

	public bool TryGetPathAt(int index, out PathData pathToUse)
	{
		if (index >= 0 && index < storedPaths.Count)
		{
			pathToUse = storedPaths[index];
			return true;
		}
		pathToUse = default(PathData);
		return false;
	}

	public bool TryGetRandomPath(out PathData pathToUse)
	{
		if (storedPaths.Count == 0)
		{
			pathToUse = default(PathData);
			return false;
		}
		pathToUse = storedPaths[Random.Range(0, storedPaths.Count)];
		return true;
	}

	public bool TryGetRandomPathWithCount(int count, out PathData pathToUse)
	{
		List<PathData> list = storedPaths.FindAll((PathData g) => g.pathPoints.Count == count);
		if (list.Count == 0)
		{
			pathToUse = default(PathData);
			return false;
		}
		pathToUse = list[Random.Range(0, list.Count)];
		return true;
	}
}
