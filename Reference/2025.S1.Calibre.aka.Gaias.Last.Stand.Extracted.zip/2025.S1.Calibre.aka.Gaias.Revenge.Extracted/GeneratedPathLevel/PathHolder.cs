using System.Collections.Generic;
using UnityEngine;

namespace GeneratedPathLevel;

public class PathHolder : MonoBehaviour
{
	public List<Vector3Path> allPaths = new List<Vector3Path>();
}
