using System;
using System.Collections.Generic;
using com.cyborgAssets.inspectorButtonPro;
using UnityEngine;

namespace GeneratedPathLevel;

[Obsolete]
public class SpawnLevelChunksStartToEnd : MonoBehaviour
{
	[Tooltip("Setting directly beside likely won't find a path")]
	[SerializeField]
	private Vector3 startChunkLocation = new Vector3(0f, 0f, 0f);

	[SerializeField]
	private Vector3 endChunkLocation = new Vector3(150f, 0f, 50f);

	[Tooltip("Setting too low, or some numbers, may not return a path")]
	[SerializeField]
	private int chunkCount = 7;

	[Header("Prefabs")]
	[SerializeField]
	private GameObject straightPrefab;

	[SerializeField]
	private GameObject turnLeftPrefab;

	[SerializeField]
	private GameObject turnRightPrefab;

	[SerializeField]
	private GameObject startPrefab;

	[SerializeField]
	private GameObject endPrefab;

	private Transform chunkHolder;

	private List<List<Vector3>> allPaths;

	[SerializeField]
	private ChunkPoolManager chunkPoolManager;

	private void Start()
	{
		SpawnLevelChunks();
	}

	private void OnDrawGizmosSelected()
	{
	}

	[ProButton]
	private void MakeGameLevel()
	{
		RemoveLevelChunks();
		SpawnLevelChunks();
	}

	[ProButton]
	private void RemoveLevelChunks()
	{
		if (chunkHolder != null)
		{
			UnityEngine.Object.DestroyImmediate(chunkHolder.gameObject);
		}
	}

	private void ReleaseChunk()
	{
	}

	private void SpawnLevelChunks()
	{
		chunkHolder = new GameObject("Level Chunk Holder").transform;
		List<Vector3> list = ChunkPathfinder.GenerateChunkPath(startChunkLocation, endChunkLocation, chunkCount);
		int length = chunkCount.ToString().Length;
		if (list == null)
		{
			return;
		}
		for (int i = 0; i < list.Count; i++)
		{
			Quaternion identity = Quaternion.identity;
			GameObject gameObject;
			if (i == 0)
			{
				gameObject = startPrefab;
				identity = Quaternion.LookRotation((list[i + 1] - list[i]).normalized, Vector3.up);
			}
			else if (i == list.Count - 1)
			{
				gameObject = endPrefab;
				identity = Quaternion.LookRotation((list[i] - list[i - 1]).normalized, Vector3.up);
			}
			else
			{
				Vector3 normalized = (list[i] - list[i - 1]).normalized;
				Vector3 normalized2 = (list[i + 1] - list[i]).normalized;
				Vector2 normalized3 = normalized.ToXZ().normalized;
				Vector2 normalized4 = normalized2.ToXZ().normalized;
				float num = Vector2.SignedAngle(normalized3, normalized4);
				if (Mathf.Approximately(num, 0f))
				{
					gameObject = straightPrefab;
					identity = Quaternion.LookRotation(normalized2, Vector3.up);
				}
				else if (num < 0f)
				{
					gameObject = turnRightPrefab;
					identity = Quaternion.LookRotation(normalized2, Vector3.up) * Quaternion.Euler(0f, -90f, 0f);
				}
				else
				{
					gameObject = turnLeftPrefab;
					identity = Quaternion.LookRotation(normalized2, Vector3.up) * Quaternion.Euler(0f, 90f, 0f);
				}
			}
			UnityEngine.Object.Instantiate(gameObject, list[i], identity, chunkHolder).name = "Chunk " + i.ToString($"D{length}") + " - " + gameObject.name;
		}
	}
}
