using System.Collections.Generic;
using System.Linq;
using com.cyborgAssets.inspectorButtonPro;
using UnityEngine;

namespace GeneratedPathLevel;

public class PathStorageAndRetrieval : MonoBehaviour
{
	[SerializeField]
	private SO_StoredGeneratedPaths pathData;

	[SerializeField]
	private RandomPathGenerator randomPathGenerator;

	[ProButton]
	public void GenerateLevelRandomly()
	{
		randomPathGenerator.GenerateLevelPointsAndShowViaLineRenderer();
	}

	public bool TryGetPath(int pathLength, out PathData pathDataOutput)
	{
		if (pathData.TryGetRandomPathWithCount(pathLength, out var pathToUse))
		{
			pathDataOutput = pathToUse;
			return true;
		}
		if (pathLength == -1 && pathData.TryGetRandomPath(out var pathToUse2))
		{
			pathDataOutput = pathToUse2;
			return true;
		}
		pathDataOutput = default(PathData);
		return false;
	}

	[ProButton]
	public void GenerateLevelFromStoredPoints(int getPathsOfLength = -1)
	{
		if (TryGetPath(getPathsOfLength, out var pathDataOutput))
		{
			randomPathGenerator.GenerateLevelFromExisitingData(pathDataOutput.pathPoints);
		}
		else
		{
			Debug.Log("No path data found. Unable to generate a level from the stored points.");
		}
	}

	[ProButton]
	public void StorePath()
	{
		PathData currentPathData = default(PathData);
		currentPathData.pathPoints = randomPathGenerator.GetGeneratedPath();
		if (pathData.GetAllPaths().Any((PathData existingPath) => ArePathPointsEqual(existingPath.pathPoints, currentPathData.pathPoints)))
		{
			Debug.Log("Identical path already exists. Nothing was added.");
			return;
		}
		pathData.AddPath(currentPathData);
		Debug.Log("Added new path group with " + currentPathData.pathPoints.Count + " sections.");
	}

	private bool ArePathPointsEqual(List<Vector2Int> list1, List<Vector2Int> list2)
	{
		if (list1.Count != list2.Count)
		{
			return false;
		}
		for (int i = 0; i < list1.Count; i++)
		{
			if (list1[i] != list2[i])
			{
				return false;
			}
		}
		return true;
	}
}
