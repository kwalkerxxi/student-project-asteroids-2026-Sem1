using System;
using System.Collections.Generic;
using UnityEngine;

namespace GeneratedPathLevel;

[Obsolete]
public static class ChunkPathfinder
{
	private static readonly Vector2Int[] directions = new Vector2Int[4]
	{
		Vector2Int.up,
		Vector2Int.down,
		Vector2Int.left,
		Vector2Int.right
	};

	public static List<Vector3> GenerateChunkPath(Vector3 worldStart, Vector3 worldEnd, int totalChunks)
	{
		Vector2Int vector2Int = new Vector2Int(Mathf.RoundToInt(worldStart.x / 50f), Mathf.RoundToInt(worldStart.z / 50f));
		Vector2Int end = new Vector2Int(Mathf.RoundToInt(worldEnd.x / 50f), Mathf.RoundToInt(worldEnd.z / 50f));
		HashSet<Vector2Int> visited = new HashSet<Vector2Int> { vector2Int };
		List<Vector2Int> list = new List<Vector2Int> { vector2Int };
		if (!FindPath(vector2Int, end, totalChunks - 1, visited, list))
		{
			Debug.LogWarning("No valid path found.");
			return null;
		}
		List<Vector3> list2 = new List<Vector3>();
		foreach (Vector2Int item in list)
		{
			list2.Add(new Vector3((float)item.x * 50f, 0f, (float)item.y * 50f));
		}
		return list2;
	}

	private static bool FindPath(Vector2Int current, Vector2Int end, int stepsRemaining, HashSet<Vector2Int> visited, List<Vector2Int> path)
	{
		if (stepsRemaining == 0)
		{
			return current == end;
		}
		List<Vector2Int> list = new List<Vector2Int>(directions);
		Shuffle(list);
		foreach (Vector2Int item in list)
		{
			Vector2Int vector2Int = current + item;
			if (!visited.Contains(vector2Int))
			{
				visited.Add(vector2Int);
				path.Add(vector2Int);
				if (FindPath(vector2Int, end, stepsRemaining - 1, visited, path))
				{
					return true;
				}
				path.RemoveAt(path.Count - 1);
				visited.Remove(vector2Int);
			}
		}
		return false;
	}

	private static void Shuffle<T>(IList<T> list)
	{
		for (int num = list.Count - 1; num > 0; num--)
		{
			int num2 = UnityEngine.Random.Range(0, num + 1);
			int index = num;
			int index2 = num2;
			T val = list[num2];
			T val2 = list[num];
			T val3 = (list[index] = val);
			val3 = (list[index2] = val2);
		}
	}

	public static List<List<Vector3>> GenerateAllChunkPaths(Vector3 start, Vector3 end, int chunkCount)
	{
		List<List<Vector3>> allPaths = new List<List<Vector3>>();
		HashSet<Vector3> visited = new HashSet<Vector3>();
		Vector3[] directions = new Vector3[4]
		{
			new Vector3(50f, 0f, 0f),
			new Vector3(-50f, 0f, 0f),
			new Vector3(0f, 0f, 50f),
			new Vector3(0f, 0f, -50f)
		};
		List<Vector3> path = new List<Vector3> { start };
		visited.Add(start);
		Backtrack(start, path);
		return allPaths;
		void Backtrack(Vector3 current, List<Vector3> list)
		{
			if (list.Count <= chunkCount)
			{
				if (list.Count == chunkCount && current == end)
				{
					allPaths.Add(new List<Vector3>(list));
				}
				else
				{
					Vector3[] array = directions;
					foreach (Vector3 vector in array)
					{
						Vector3 vector2 = current + vector;
						if (!visited.Contains(vector2))
						{
							list.Add(vector2);
							visited.Add(vector2);
							Backtrack(vector2, list);
							list.RemoveAt(list.Count - 1);
							visited.Remove(vector2);
						}
					}
				}
			}
		}
	}
}
